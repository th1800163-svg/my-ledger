# My Ledger (project name: amar_hisab)

Personal business and household ledger for one owner: chicken business, hotel and
customer credit, five autos, household expenses. English UI, offline, SQLite.

## Status

Built in sequential parts (see the design document, Part 1):

| Part | Content | State |
|---|---|---|
| 1 | Design | done |
| 2A | Core foundation (money, weight, parsing, formatting, dates, validation, database, migrations, tests) | **this delivery** |
| 2B | App shell, theme, reusable widgets, providers | next |
| 3 | Settings, chicken, ledgers (customers, hotels) | |
| 4 | Autos, expenses | |
| 5 | Summary, dashboard, reports, PDF, backup | |
| 6 | Remaining tests, final review, build | |

## Run the tests (Part 2A)

```bash
flutter pub get
flutter test
```

The database tests use `sqflite_common_ffi`, which needs the SQLite library on the
computer running the tests. macOS has it built in. On Linux install it
(`sudo apt install libsqlite3-dev`). On Windows, if the tests cannot find
`sqlite3.dll`, download it from sqlite.org and put it next to the Flutter tool, or
run the tests on a machine that has it. If you see a message about a missing
SQLite library, that is the cause, not a bug in the app.

Delete the generated `test/widget_test.dart` first (it tests the default counter
app that `flutter create` makes).

## Small differences from the Part 1 design (all deliberate)

- Part 2 is delivered in two halves: **2A** (this one: everything that has no screen)
  and **2B** (app shell, theme, widgets, providers), so each half can be tested.
- `AppStrings` holds only wording shared by the whole app. Feature-specific wording
  will live inside each feature folder, so adding a screen never means re-issuing
  this file.
- Extra support files not named in the folder list: `decimal_parser.dart`,
  `validated.dart`, `row_reader.dart`, `db_errors.dart`, `request_id.dart`,
  `seed_data.dart`, `settings_defaults.dart`.
- A `first_run_completed` setting was added (drives the first-run setup screen).
- The database has more guards than the design listed: besides refusing overpayment,
  it also refuses lowering a bill (or an auto's expected deposit) below what is
  already paid, and refuses deleting a bill (or an auto day) that has active
  payments. These enforce rule R10 even if screen code has a bug. The sales CHECK
  rules are also stricter (for example an estimated weight must equal pieces x the
  stored average).
- Money and weight validation limits live in `core/validation/limits.dart`.

## What was verified, and what was not

- The SQL schema (tables, CHECK rules, triggers, views, seed data) was executed in
  SQLite and tested with 94 checks, all passing. The SQL text inside
  `m001_initial.dart` and `views.dart` was extracted from those Dart files and
  executed again to prove it is identical.
- The Dart code and the Dart tests have **not** been compiled or run (no Dart SDK
  was available). Run `flutter test` and report any failure.
