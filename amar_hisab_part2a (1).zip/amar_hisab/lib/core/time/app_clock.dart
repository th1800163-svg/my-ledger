/// The only place the app asks "what time is it?".
///
/// Business code takes an [AppClock] instead of calling `DateTime.now()`, so
/// tests can run at a fixed moment and the date, time and transaction numbers
/// they produce are predictable.
abstract interface class AppClock {
  /// The current local date and time.
  DateTime now();
}

/// The real clock, used in the running app.
final class SystemClock implements AppClock {
  const SystemClock();

  @override
  DateTime now() => DateTime.now();
}

/// A clock you control by hand. Used in tests.
final class FixedClock implements AppClock {
  FixedClock(DateTime start) : _now = start;

  DateTime _now;

  @override
  DateTime now() => _now;

  /// Jumps to a new moment.
  void set(DateTime value) => _now = value;

  /// Moves the clock forward (or backward with a negative duration).
  void advance(Duration duration) => _now = _now.add(duration);
}

extension AppClockToday on AppClock {
  /// Today's date at midnight (local time).
  DateTime get today {
    final value = now();
    return DateTime(value.year, value.month, value.day);
  }
}
