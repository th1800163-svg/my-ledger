import 'package:intl/intl.dart';

/// Date and time conversion for storage and for display.
///
/// Storage formats are fixed and sortable as plain text:
/// - date `YYYY-MM-DD` and time `HH:MM:SS` in the phone's local time,
/// - audit timestamps as ISO-8601 in UTC.
///
/// Display formats are English: `07 Oct 2026` and `3:45 PM`.
abstract final class AppDate {
  static final RegExp _dbDatePattern = RegExp(r'^(\d{4})-(\d{2})-(\d{2})$');
  static final RegExp _dbTimePattern = RegExp(r'^(\d{2}):(\d{2}):(\d{2})$');

  static final DateFormat _dateFormat = DateFormat('dd MMM yyyy', 'en_US');
  static final DateFormat _timeFormat = DateFormat('h:mm a', 'en_US');
  static final DateFormat _monthFormat = DateFormat('MMMM yyyy', 'en_US');

  static String _two(int value) => value.toString().padLeft(2, '0');

  // ---- storage ----------------------------------------------------------

  /// `2026-10-07`
  static String toDbDate(DateTime value) =>
      '${value.year.toString().padLeft(4, '0')}-${_two(value.month)}-${_two(value.day)}';

  /// `15:45:30`
  static String toDbTime(DateTime value) =>
      '${_two(value.hour)}:${_two(value.minute)}:${_two(value.second)}';

  /// `2026-10-07T09:45:30.000Z` (always UTC)
  static String toUtcIso(DateTime value) => value.toUtc().toIso8601String();

  /// Parses `YYYY-MM-DD`. Throws [FormatException] for anything else,
  /// including impossible dates such as `2026-02-30`.
  static DateTime parseDbDate(String text) {
    final match = _dbDatePattern.firstMatch(text);
    if (match == null) throw FormatException('Not a YYYY-MM-DD date', text);
    final year = int.parse(match.group(1)!);
    final month = int.parse(match.group(2)!);
    final day = int.parse(match.group(3)!);
    final parsed = DateTime(year, month, day);
    if (parsed.year != year || parsed.month != month || parsed.day != day) {
      throw FormatException('Not a real calendar date', text);
    }
    return parsed;
  }

  /// Combines a stored date and time into one local [DateTime].
  static DateTime parseDbDateTime(String date, String time) {
    final day = parseDbDate(date);
    final match = _dbTimePattern.firstMatch(time);
    if (match == null) throw FormatException('Not an HH:MM:SS time', time);
    final hour = int.parse(match.group(1)!);
    final minute = int.parse(match.group(2)!);
    final second = int.parse(match.group(3)!);
    if (hour > 23 || minute > 59 || second > 59) {
      throw FormatException('Not a real time of day', time);
    }
    return DateTime(day.year, day.month, day.day, hour, minute, second);
  }

  static bool isValidDbDate(String text) {
    try {
      parseDbDate(text);
      return true;
    } on FormatException {
      return false;
    }
  }

  // ---- display ----------------------------------------------------------

  /// `07 Oct 2026`
  static String display(DateTime value) => _dateFormat.format(value);

  /// `3:45 PM`
  static String displayTime(DateTime value) => _timeFormat.format(value);

  /// `07 Oct 2026, 3:45 PM`
  static String displayDateTime(DateTime value) =>
      '${display(value)}, ${displayTime(value)}';

  /// `October 2026`
  static String displayMonth(DateTime value) => _monthFormat.format(value);

  /// Display text for a stored `YYYY-MM-DD` date.
  static String displayDbDate(String text) => display(parseDbDate(text));

  /// Display text for a stored `HH:MM:SS` time.
  static String displayDbTime(String text) =>
      displayTime(parseDbDateTime('2000-01-01', text));

  // ---- calendar helpers -------------------------------------------------

  static DateTime dateOnly(DateTime value) =>
      DateTime(value.year, value.month, value.day);

  /// Adds whole calendar days. Built from year/month/day, so it never drifts
  /// by an hour across a daylight-saving change.
  static DateTime addDays(DateTime value, int days) =>
      DateTime(value.year, value.month, value.day + days);

  static bool isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  static DateTime startOfMonth(DateTime value) => DateTime(value.year, value.month, 1);

  static DateTime endOfMonth(DateTime value) => DateTime(value.year, value.month + 1, 0);

  /// The first day of the week containing [value].
  ///
  /// Bangladesh's week starts on Saturday, so that is the default.
  static DateTime startOfWeek(DateTime value, {int weekStartsOn = DateTime.saturday}) {
    final day = dateOnly(value);
    final daysSinceStart = (day.weekday - weekStartsOn + 7) % 7;
    return addDays(day, -daysSinceStart);
  }
}
