/// Base class for every error the app shows to the owner.
///
/// [message] is always plain English that is safe to display. The technical
/// [cause] (for example a database exception) is kept for debugging only.
sealed class AppException implements Exception {
  const AppException(this.message, {this.cause});

  final String message;
  final Object? cause;

  @override
  String toString() => '$runtimeType: $message';
}

/// Input that failed validation.
final class ValidationException extends AppException {
  const ValidationException(super.message, {super.cause});
}

/// A business rule stopped the action (receiving more than is due, deleting a
/// bill that has payments, ...).
final class BusinessRuleException extends AppException {
  const BusinessRuleException(super.message, {this.code, super.cause});

  /// Machine-readable reason, e.g. `overpay`, `has_payments`.
  final String? code;
}

/// A record that should exist was not found.
final class NotFoundException extends AppException {
  const NotFoundException(super.message, {super.cause});
}

/// The same save arrived twice (double tap, retry). The first save is kept.
final class DuplicateSubmissionException extends AppException {
  const DuplicateSubmissionException(super.message, {super.cause});
}

/// The database failed in a way the owner cannot fix.
final class DatabaseFailure extends AppException {
  const DatabaseFailure(super.message, {super.cause});
}

/// Backup, restore or export failed.
final class BackupException extends AppException {
  const BackupException(super.message, {super.cause});
}
