/// Converts Bengali digits (০-৯) to Latin digits (0-9).
///
/// The app is English, but a phone with a Bengali keyboard can still type
/// Bengali digits into numeric fields. Every parser calls this first so the
/// owner never sees "invalid number" for a perfectly good Bengali number.
String normalizeDigits(String input) {
  final buffer = StringBuffer();
  for (final rune in input.runes) {
    if (rune >= 0x09E6 && rune <= 0x09EF) {
      buffer.writeCharCode(0x30 + (rune - 0x09E6));
    } else {
      buffer.writeCharCode(rune);
    }
  }
  return buffer.toString();
}

/// Cleans text typed into a numeric field before it is parsed.
///
/// - Bengali digits become Latin digits.
/// - Whitespace (including non-breaking spaces) and thousands commas are removed.
/// - The typographic minus sign (U+2212) becomes a normal '-', so that a
///   negative number is reported as negative instead of "not a number".
String normalizeNumberInput(String input) {
  final digits = normalizeDigits(input).replaceAll('\u2212', '-');
  return digits.replaceAll(RegExp(r'[\s,]'), '');
}
