import 'package:amar_hisab/core/money/money.dart';

/// How big numbers are grouped with commas.
enum NumberGrouping {
  /// Bangladeshi / South Asian: 12,50,000.50 (lakh and crore).
  southAsian,

  /// International: 1,250,000.50.
  international,
}

/// Turns [Money] into text for the screen, reports and PDFs.
///
/// Whole-Taka amounts show no decimals (৳7,000); amounts with paisa show two
/// (৳7,000.50). Pass `fixedDecimals: true` where columns must line up.
final class MoneyFormat {
  const MoneyFormat({
    this.symbol = '৳',
    this.grouping = NumberGrouping.southAsian,
  });

  /// The currency symbol, normally ৳ (alternatives: "Tk", "BDT").
  final String symbol;
  final NumberGrouping grouping;

  /// Default format, used wherever settings are not available.
  static const MoneyFormat standard = MoneyFormat();

  String format(Money amount, {bool withSymbol = true, bool fixedDecimals = false}) {
    final negative = amount.paisa < 0;
    final absolute = amount.paisa.abs();
    final whole = absolute ~/ 100;
    final cents = absolute % 100;

    final digits = groupDigits(whole.toString());
    final body = (fixedDecimals || cents != 0)
        ? '$digits.${cents.toString().padLeft(2, '0')}'
        : digits;

    final prefix = withSymbol ? _symbolPrefix : '';
    return '${negative ? '-' : ''}$prefix$body';
  }

  /// The ৳ sign sits directly before the number; text symbols get a space.
  String get _symbolPrefix => symbol == '৳' ? symbol : '$symbol ';

  /// Inserts thousands separators into a string of plain digits.
  String groupDigits(String digits) {
    if (digits.length <= 3) return digits;
    final lastThree = digits.substring(digits.length - 3);
    var rest = digits.substring(0, digits.length - 3);
    final groupSize = grouping == NumberGrouping.southAsian ? 2 : 3;

    final groups = <String>[];
    while (rest.length > groupSize) {
      groups.insert(0, rest.substring(rest.length - groupSize));
      rest = rest.substring(0, rest.length - groupSize);
    }
    if (rest.isNotEmpty) groups.insert(0, rest);
    return '${groups.join(',')},$lastThree';
  }
}
