/// Wording shared by the whole app (buttons, statuses, units, periods).
///
/// Feature-specific wording lives next to its feature, so adding a screen
/// never means editing this file. The app is English only.
abstract final class AppStrings {
  // ---- actions ----
  static const String save = 'Save';
  static const String cancel = 'Cancel';
  static const String delete = 'Delete';
  static const String edit = 'Edit';
  static const String add = 'Add';
  static const String done = 'Done';
  static const String close = 'Close';
  static const String confirm = 'Confirm';
  static const String yes = 'Yes';
  static const String no = 'No';
  static const String retry = 'Try again';
  static const String search = 'Search';
  static const String clear = 'Clear';
  static const String receive = 'Receive';
  static const String call = 'Call';
  static const String share = 'Share';

  // ---- feedback ----
  static const String saved = 'Saved';
  static const String deleted = 'Deleted';
  static const String loading = 'Loading…';
  static const String nothingHereYet = 'Nothing here yet';
  static const String somethingWentWrong = 'Something went wrong. Please try again.';
  static const String saving = 'Saving…';

  // ---- payment status (always shown as text, never colour alone) ----
  static const String statusDue = 'Due';
  static const String statusPartial = 'Partially paid';
  static const String statusPaid = 'Paid';

  // ---- chicken ----
  static const String broiler = 'Broiler';
  static const String sonali = 'Sonali';
  static const String estimatedWeight = 'Estimated weight';
  static const String saleByWeight = 'By weight';
  static const String saleByPieces = 'By pieces';
  static const String saleByAmount = 'By amount';

  // ---- auto status ----
  static const String autoFullTime = 'Full Time';
  static const String autoHalfTime = 'Half Time';
  static const String autoSick = 'Sick';
  static const String autoBroken = 'Broken';
  static const String autoLeave = 'Leave';

  // ---- units ----
  static const String kg = 'kg';
  static const String pieces = 'pcs';

  // ---- periods ----
  static const String today = 'Today';
  static const String yesterday = 'Yesterday';
  static const String thisWeek = 'This week';
  static const String thisMonth = 'This month';
  static const String customRange = 'Custom range';
}

/// Error messages for typed input. Every message names the field so the owner
/// knows exactly what to fix.
abstract final class ValidationText {
  static String required(String label) => '$label is required';
  static String notANumber(String label) => '$label must be a number';
  static String notWholeNumber(String label) => '$label must be a whole number';
  static String negative(String label) => '$label cannot be negative';
  static String greaterThanZero(String label) => '$label must be greater than zero';
  static String tooManyDecimals(String label, int places) =>
      '$label can have at most $places decimal places';
  static String tooLarge(String label) => '$label is too large';
  static String maxAllowed(String label, String formattedMax) =>
      '$label cannot be more than $formattedMax';
  static String percentRange(String label) => '$label must be between 0 and 100';
  static String nameTooLong(String label, int max) =>
      '$label can have at most $max characters';
  static String textTooLong(String label, int max) =>
      '$label can have at most $max characters';
  static const String invalidPhone =
      'Enter a valid Bangladeshi phone number, for example 01712345678';
  static const String futureDate = 'The date and time cannot be in the future';
  static const String nothingDue = 'Nothing is due';
  static String receiveMoreThanDue(String formattedDue) =>
      'You can receive at most $formattedDue (the amount still due)';
  static String paidMoreThanTotal(String formattedTotal) =>
      'The paid amount cannot be more than the total ($formattedTotal)';
}
