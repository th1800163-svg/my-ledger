import 'package:amar_hisab/core/db/migrations/m001_initial.dart';
import 'package:amar_hisab/core/db/views.dart';
import 'package:sqflite/sqflite.dart';

/// One schema change. Step number N takes the database from version N-1 to N.
typedef MigrationStep = Future<void> Function(DatabaseExecutor db, DateTime nowUtc);

/// Runs schema migrations in order.
///
/// To change the schema in future: add `m002_something.dart`, append its
/// function to [steps], and raise `AppDatabase.schemaVersion` by one. Existing
/// installs are upgraded step by step; new installs run every step from 1.
/// Views are rebuilt after every run, so they never need their own step.
abstract final class MigrationRunner {
  static final List<MigrationStep> steps = <MigrationStep>[
    m001Initial,
  ];

  /// The newest schema version this build of the app understands.
  static int get latestVersion => steps.length;

  static Future<void> onCreate(DatabaseExecutor db, int version, DateTime nowUtc) =>
      _apply(db, 0, version, nowUtc);

  static Future<void> onUpgrade(
    DatabaseExecutor db,
    int oldVersion,
    int newVersion,
    DateTime nowUtc,
  ) =>
      _apply(db, oldVersion, newVersion, nowUtc);

  static Future<void> _apply(
    DatabaseExecutor db,
    int from,
    int to,
    DateTime nowUtc,
  ) async {
    if (to > steps.length) {
      throw StateError('No migration exists for schema version $to');
    }
    for (var version = from + 1; version <= to; version++) {
      await steps[version - 1](db, nowUtc);
    }
    await Views.recreate(db);
  }
}
