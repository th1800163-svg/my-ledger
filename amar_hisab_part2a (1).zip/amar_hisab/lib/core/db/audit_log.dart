import 'dart:convert';

import 'package:amar_hisab/core/time/date_format.dart';
import 'package:sqflite/sqflite.dart';

/// What happened to a record.
enum AuditAction {
  create('create'),
  update('update'),
  delete('delete');

  const AuditAction(this.code);

  final String code;
}

/// An append-only history of changes (rule R10).
///
/// Nothing in the app edits or removes audit rows. When a record is changed,
/// its old and new values are stored here as JSON, so history can never be
/// overwritten without a trace.
abstract final class AuditLog {
  /// Records one change. Call it inside the same transaction as the change.
  static Future<void> record(
    DatabaseExecutor txn, {
    required String table,
    required int recordId,
    required AuditAction action,
    required DateTime now,
    Map<String, Object?>? oldValues,
    Map<String, Object?>? newValues,
  }) async {
    await txn.insert('audit_log', <String, Object?>{
      'table_name': table,
      'record_id': recordId,
      'action': action.code,
      'old_json': oldValues == null ? null : jsonEncode(oldValues),
      'new_json': newValues == null ? null : jsonEncode(newValues),
      'created_at': AppDate.toUtcIso(now),
    });
  }

  /// All history entries for one record, oldest first.
  static Future<List<Map<String, Object?>>> historyOf(
    DatabaseExecutor db, {
    required String table,
    required int recordId,
  }) {
    return db.query(
      'audit_log',
      where: 'table_name = ? AND record_id = ?',
      whereArgs: <Object?>[table, recordId],
      orderBy: 'id ASC',
    );
  }
}
