import 'dart:math';

/// Creates the one-per-form key used to stop double saves.
///
/// A form creates its key when it opens. Tapping Save twice, or retrying after
/// an error, sends the same key, and the database's UNIQUE(request_id) rule
/// guarantees only one row is ever created for it.
abstract final class RequestId {
  static final Random _secure = Random.secure();

  /// 32 random hex characters (128 bits). Pass [random] in tests for a
  /// predictable sequence.
  static String generate([Random? random]) {
    final source = random ?? _secure;
    final buffer = StringBuffer();
    for (var i = 0; i < 16; i++) {
      buffer.write(source.nextInt(256).toRadixString(16).padLeft(2, '0'));
    }
    return buffer.toString();
  }
}
