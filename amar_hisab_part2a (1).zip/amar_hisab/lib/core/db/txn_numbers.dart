import 'package:sqflite/sqflite.dart';

/// Prefixes of the human-readable transaction numbers (rule R11).
enum TxnPrefix {
  purchase('PUR'),
  retailSale('RET'),
  customerBill('CUS'),
  hotelBill('HTL'),
  customerReceipt('RCC'),
  hotelReceipt('RCH'),
  autoStatus('AST'),
  autoDeposit('DEP'),
  autoExpense('AEX'),
  householdExpense('HEX'),
  generalExpense('GEX');

  const TxnPrefix(this.code);

  final String code;
}

/// Creates numbers like `PUR-20261007-003`: prefix, transaction date, and a
/// per-day running counter.
///
/// The counter lives in the `txn_counters` table and is advanced inside the
/// caller's SQL transaction. If the save fails and rolls back, the counter
/// rolls back with it, so numbers never have gaps from failed saves. The
/// UNIQUE rule on the number columns is a second safeguard.
abstract final class TxnNumbers {
  /// Reserves and returns the next number for [prefix] on [date].
  ///
  /// [date] is the transaction's date (not necessarily today), so a
  /// back-dated entry gets a number that matches its own date.
  static Future<String> next(
    DatabaseExecutor txn,
    TxnPrefix prefix,
    DateTime date,
  ) async {
    final key = '${prefix.code}-${_compactDate(date)}';

    final updated = await txn.rawUpdate(
      'UPDATE txn_counters SET last_value = last_value + 1 WHERE counter_key = ?',
      <Object?>[key],
    );
    if (updated == 0) {
      await txn.insert('txn_counters', <String, Object?>{
        'counter_key': key,
        'last_value': 1,
      });
    }

    final rows = await txn.query(
      'txn_counters',
      columns: <String>['last_value'],
      where: 'counter_key = ?',
      whereArgs: <Object?>[key],
    );
    final sequence = rows.first['last_value']! as int;
    return '$key-${sequence.toString().padLeft(3, '0')}';
  }

  static String _compactDate(DateTime date) {
    final month = date.month.toString().padLeft(2, '0');
    final day = date.day.toString().padLeft(2, '0');
    return '${date.year.toString().padLeft(4, '0')}$month$day';
  }
}
