import 'package:amar_hisab/core/errors/app_exception.dart';

/// What kind of database failure happened.
enum DbErrorKind {
  /// The same form was submitted twice (UNIQUE on request_id).
  duplicateRequest,

  /// A transaction number collided (UNIQUE on txn_no / receipt_no).
  duplicateNumber,

  /// Some other UNIQUE rule, such as one status per auto per day.
  duplicateOther,

  /// More money than is due (database trigger).
  overpay,

  /// A bill total or expected deposit was lowered below what is already paid.
  belowPaid,

  /// A bill or day with active payments was deleted.
  hasPayments,

  /// A CHECK constraint (a formula or allowed-values rule) failed.
  checkFailed,

  /// A foreign key pointed at a record that does not exist.
  foreignKey,

  other,
}

/// Turns raw database exceptions into [AppException]s with plain English
/// messages.
abstract final class DbErrors {
  static DbErrorKind classify(Object error) {
    final text = error.toString();
    if (text.contains('OVERPAY')) return DbErrorKind.overpay;
    if (text.contains('BELOW_PAID')) return DbErrorKind.belowPaid;
    if (text.contains('HAS_PAYMENTS')) return DbErrorKind.hasPayments;
    if (text.contains('UNIQUE constraint failed')) {
      if (text.contains('request_id')) return DbErrorKind.duplicateRequest;
      if (text.contains('txn_no') || text.contains('receipt_no')) {
        return DbErrorKind.duplicateNumber;
      }
      return DbErrorKind.duplicateOther;
    }
    if (text.contains('CHECK constraint failed')) return DbErrorKind.checkFailed;
    if (text.contains('FOREIGN KEY constraint failed')) return DbErrorKind.foreignKey;
    return DbErrorKind.other;
  }

  /// The [AppException] to show for [error]. An [AppException] passes through
  /// unchanged.
  static AppException toAppException(Object error) {
    if (error is AppException) return error;
    switch (classify(error)) {
      case DbErrorKind.duplicateRequest:
        return DuplicateSubmissionException(
          'This entry was already saved.',
          cause: error,
        );
      case DbErrorKind.duplicateNumber:
        return DatabaseFailure(
          'Could not create a unique transaction number. Please try again.',
          cause: error,
        );
      case DbErrorKind.duplicateOther:
        return BusinessRuleException(
          'An entry with the same details already exists.',
          code: 'duplicate',
          cause: error,
        );
      case DbErrorKind.overpay:
        return BusinessRuleException(
          'That amount is more than what is still due.',
          code: 'overpay',
          cause: error,
        );
      case DbErrorKind.belowPaid:
        return BusinessRuleException(
          'The new amount cannot be less than what has already been paid.',
          code: 'below_paid',
          cause: error,
        );
      case DbErrorKind.hasPayments:
        return BusinessRuleException(
          'This record has payments. Cancel its payments first.',
          code: 'has_payments',
          cause: error,
        );
      case DbErrorKind.checkFailed:
        return BusinessRuleException(
          'Some of the entered values do not add up. Please check them.',
          code: 'check_failed',
          cause: error,
        );
      case DbErrorKind.foreignKey:
        return BusinessRuleException(
          'A related record could not be found.',
          code: 'missing_reference',
          cause: error,
        );
      case DbErrorKind.other:
        return DatabaseFailure(
          'The data could not be saved. Please try again.',
          cause: error,
        );
    }
  }
}
