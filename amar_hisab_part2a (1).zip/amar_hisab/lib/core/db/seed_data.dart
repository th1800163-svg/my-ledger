/// Built-in expense categories. This is configuration, not sample data: the
/// categories requested for autos and household, plus "Other" for general
/// expenses. Custom categories can be added at any time from the app.
abstract final class SeedData {
  static const List<String> autoCategories = <String>[
    'Battery',
    'Motor',
    'Bearing',
    'Tyre',
    'Tube',
    'Charger',
    'Brake',
    'Chain',
    'Gear',
    'Light',
    'Controller',
    'Wiring',
    'Rim',
    'Seat',
    'Suspension',
    'Nuts & bolts',
    'Repair labour/mechanic',
    'Other',
  ];

  static const List<String> householdCategories = <String>[
    'Food/Groceries',
    'Medicine',
    'Water',
    'Electricity',
    'Gas',
    'House rent',
    'Furniture',
    'Clothes',
    'Education',
    'Transport',
    'Mobile/Internet',
    'Household supplies',
    'Family expenses',
    'Other',
  ];

  static const List<String> generalCategories = <String>[
    'Other',
  ];
}
