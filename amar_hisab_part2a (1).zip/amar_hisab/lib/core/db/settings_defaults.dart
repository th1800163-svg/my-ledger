/// Keys of the `settings` table.
abstract final class SettingKeys {
  static const String appName = 'app_name';
  static const String ownerName = 'owner_name';
  static const String currencySymbol = 'currency_symbol';
  static const String numberGrouping = 'number_grouping';
  static const String avgPieceWeightGBroiler = 'avg_piece_weight_g_broiler';
  static const String avgPieceWeightGSonali = 'avg_piece_weight_g_sonali';
  static const String halfTimePercent = 'half_time_percent';
  static const String sickExpectedDefault = 'sick_expected_default';
  static const String brokenExpectedDefault = 'broken_expected_default';
  static const String yieldPercentBroiler = 'yield_percent_broiler';
  static const String yieldPercentSonali = 'yield_percent_sonali';
  static const String pdfPaper = 'pdf_paper';
  static const String pdfIncludeDetails = 'pdf_include_details';
  static const String pdfShowPhone = 'pdf_show_phone';
  static const String firstRunCompleted = 'first_run_completed';
  static const String dbAppId = 'db_app_id';
}

/// Values written into `settings` when the database is first created.
///
/// No rates, autos, customers or hotels are pre-filled: those are real data
/// the owner enters in the first-run setup. The two average piece weights are
/// only starting values and can be changed in Settings.
abstract final class SettingDefaults {
  static const Map<String, String> values = <String, String>{
    SettingKeys.appName: 'My Ledger',
    SettingKeys.ownerName: '',
    SettingKeys.currencySymbol: '৳',
    SettingKeys.numberGrouping: 'south_asian',
    SettingKeys.avgPieceWeightGBroiler: '2000',
    SettingKeys.avgPieceWeightGSonali: '1500',
    SettingKeys.halfTimePercent: '50',
    SettingKeys.sickExpectedDefault: 'zero',
    SettingKeys.brokenExpectedDefault: 'zero',
    SettingKeys.yieldPercentBroiler: '100',
    SettingKeys.yieldPercentSonali: '100',
    SettingKeys.pdfPaper: 'A4',
    SettingKeys.pdfIncludeDetails: '1',
    SettingKeys.pdfShowPhone: '1',
    SettingKeys.firstRunCompleted: '0',
    SettingKeys.dbAppId: appId,
  };

  /// Written into every database so that a restore can recognise our files.
  static const String appId = 'amar_hisab';
}
