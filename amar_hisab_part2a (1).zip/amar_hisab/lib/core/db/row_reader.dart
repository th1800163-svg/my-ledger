import 'package:amar_hisab/core/money/money.dart';
import 'package:amar_hisab/core/money/weight.dart';

/// Typed access to a database row.
///
/// `sqflite` hands back `Map<String, Object?>`. These helpers read a column
/// with the right type and fail loudly (with the column name) if the data is
/// not what the schema promises, instead of silently producing a wrong value.
extension RowReader on Map<String, Object?> {
  int intOf(String column) {
    final value = this[column];
    if (value is int) return value;
    throw StateError('Column "$column" should be an int but is $value');
  }

  int? intOrNull(String column) {
    final value = this[column];
    if (value == null) return null;
    if (value is int) return value;
    throw StateError('Column "$column" should be an int or null but is $value');
  }

  String stringOf(String column) {
    final value = this[column];
    if (value is String) return value;
    throw StateError('Column "$column" should be a string but is $value');
  }

  String? stringOrNull(String column) {
    final value = this[column];
    if (value == null) return null;
    if (value is String) return value;
    throw StateError('Column "$column" should be a string or null but is $value');
  }

  /// SQLite has no boolean type; flags are stored as 0 or 1.
  bool boolOf(String column) => intOf(column) == 1;

  Money moneyOf(String column) => Money(intOf(column));

  Money? moneyOrNull(String column) {
    final value = intOrNull(column);
    return value == null ? null : Money(value);
  }

  Weight weightOf(String column) => Weight(intOf(column));

  Weight? weightOrNull(String column) {
    final value = intOrNull(column);
    return value == null ? null : Weight(value);
  }
}
