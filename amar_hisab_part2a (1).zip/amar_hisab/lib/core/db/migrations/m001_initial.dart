import 'package:amar_hisab/core/db/seed_data.dart';
import 'package:amar_hisab/core/db/settings_defaults.dart';
import 'package:amar_hisab/core/time/date_format.dart';
import 'package:sqflite/sqflite.dart';

/// Migration 1: the complete initial schema, built-in expense categories and
/// default settings.
///
/// Every statement runs on its own because Android's SQLite executes only the
/// first statement of a multi-statement string. Triggers contain semicolons
/// inside BEGIN ... END, so splitting a big string on ';' is not safe either.
///
/// Money columns are integer paisa (`*_paisa`), weights are integer grams
/// (`*_g`). CHECK constraints repeat the key business formulas so that the
/// database itself refuses inconsistent rows even if application code has a
/// bug. Views are created separately by `Views.recreate` after every
/// migration, so they are intentionally not part of this file.
Future<void> m001Initial(DatabaseExecutor db, DateTime nowUtc) async {
  for (final statement in m001SchemaStatements) {
    await db.execute(statement);
  }

  final timestamp = AppDate.toUtcIso(nowUtc);

  for (final entry in SettingDefaults.values.entries) {
    await db.insert('settings', <String, Object?>{
      'key': entry.key,
      'value': entry.value,
      'updated_at': timestamp,
    });
  }

  await _seedCategories(db, 'auto', SeedData.autoCategories, timestamp);
  await _seedCategories(db, 'household', SeedData.householdCategories, timestamp);
  await _seedCategories(db, 'general', SeedData.generalCategories, timestamp);
}

Future<void> _seedCategories(
  DatabaseExecutor db,
  String scope,
  List<String> names,
  String timestamp,
) async {
  for (var i = 0; i < names.length; i++) {
    await db.insert('expense_categories', <String, Object?>{
      'scope': scope,
      'name': names[i],
      'is_builtin': 1,
      'is_active': 1,
      'sort_order': i,
      'created_at': timestamp,
    });
  }
}

/// The schema, one statement per list entry.
const List<String> m001SchemaStatements = <String>[
  r"""CREATE TABLE settings (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL,
  updated_at TEXT NOT NULL
)""",
  r"""CREATE TABLE txn_counters (
  counter_key TEXT PRIMARY KEY,
  last_value INTEGER NOT NULL CHECK (last_value >= 0)
)""",
  r"""CREATE TABLE audit_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  table_name TEXT NOT NULL,
  record_id INTEGER NOT NULL,
  action TEXT NOT NULL CHECK (action IN ('create','update','delete')),
  old_json TEXT,
  new_json TEXT,
  created_at TEXT NOT NULL
)""",
  r"""CREATE TABLE chicken_rates (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  chicken_type TEXT NOT NULL CHECK (chicken_type IN ('broiler','sonali')),
  rate_per_kg_paisa INTEGER NOT NULL CHECK (rate_per_kg_paisa > 0),
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  created_at TEXT NOT NULL
)""",
  r"""CREATE TABLE dealers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  name_key TEXT NOT NULL UNIQUE,
  phone TEXT,
  address TEXT,
  notes TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
)""",
  r"""CREATE TABLE purchases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  dealer_id INTEGER NOT NULL REFERENCES dealers(id),
  chicken_type TEXT NOT NULL CHECK (chicken_type IN ('broiler','sonali')),
  pieces INTEGER NOT NULL CHECK (pieces >= 0),
  weight_g INTEGER NOT NULL CHECK (weight_g > 0),
  rate_per_kg_paisa INTEGER NOT NULL CHECK (rate_per_kg_paisa > 0),
  chicken_cost_paisa INTEGER NOT NULL
    CHECK (chicken_cost_paisa = (weight_g * rate_per_kg_paisa + 500) / 1000),
  transport_paisa INTEGER NOT NULL DEFAULT 0 CHECK (transport_paisa >= 0),
  other_paisa INTEGER NOT NULL DEFAULT 0 CHECK (other_paisa >= 0),
  grand_total_paisa INTEGER NOT NULL
    CHECK (grand_total_paisa = chicken_cost_paisa + transport_paisa + other_paisa)
)""",
  r"""CREATE TABLE retail_sales (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  chicken_type TEXT NOT NULL CHECK (chicken_type IN ('broiler','sonali')),
  sale_mode TEXT NOT NULL CHECK (sale_mode IN ('weight','piece','amount')),
  pieces INTEGER NOT NULL DEFAULT 0 CHECK (pieces >= 0),
  actual_weight_g INTEGER CHECK (actual_weight_g IS NULL OR actual_weight_g > 0),
  estimated_weight_g INTEGER CHECK (estimated_weight_g IS NULL OR estimated_weight_g > 0),
  weight_source TEXT NOT NULL CHECK (weight_source IN ('actual','estimated','none')),
  avg_piece_weight_g_used INTEGER CHECK (avg_piece_weight_g_used IS NULL OR avg_piece_weight_g_used > 0),
  rate_per_kg_paisa INTEGER CHECK (rate_per_kg_paisa IS NULL OR rate_per_kg_paisa >= 0),
  total_paisa INTEGER NOT NULL CHECK (total_paisa > 0),
  CHECK ((weight_source = 'actual') = (actual_weight_g IS NOT NULL)),
  CHECK ((weight_source = 'estimated') = (estimated_weight_g IS NOT NULL)),
  CHECK (weight_source <> 'estimated' OR avg_piece_weight_g_used IS NOT NULL),
  CHECK (weight_source <> 'estimated' OR estimated_weight_g = pieces * avg_piece_weight_g_used),
  CHECK (sale_mode <> 'weight' OR weight_source = 'actual'),
  CHECK (sale_mode <> 'piece' OR pieces > 0),
  CHECK (sale_mode = 'amount' OR weight_source <> 'none'),
  CHECK (sale_mode <> 'amount' OR weight_source <> 'estimated'),
  CHECK (sale_mode = 'amount' OR rate_per_kg_paisa IS NOT NULL),
  CHECK (sale_mode = 'amount' OR total_paisa =
         (COALESCE(actual_weight_g, estimated_weight_g) * rate_per_kg_paisa + 500) / 1000)
)""",
  r"""CREATE TABLE customers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT,
  address_note TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
)""",
  r"""CREATE TABLE customer_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  customer_id INTEGER NOT NULL REFERENCES customers(id),
  chicken_type TEXT NOT NULL CHECK (chicken_type IN ('broiler','sonali')),
  sale_mode TEXT NOT NULL CHECK (sale_mode IN ('weight','piece','amount')),
  pieces INTEGER NOT NULL DEFAULT 0 CHECK (pieces >= 0),
  actual_weight_g INTEGER CHECK (actual_weight_g IS NULL OR actual_weight_g > 0),
  estimated_weight_g INTEGER CHECK (estimated_weight_g IS NULL OR estimated_weight_g > 0),
  weight_source TEXT NOT NULL CHECK (weight_source IN ('actual','estimated','none')),
  avg_piece_weight_g_used INTEGER CHECK (avg_piece_weight_g_used IS NULL OR avg_piece_weight_g_used > 0),
  rate_per_kg_paisa INTEGER CHECK (rate_per_kg_paisa IS NULL OR rate_per_kg_paisa >= 0),
  total_paisa INTEGER NOT NULL CHECK (total_paisa > 0),
  CHECK ((weight_source = 'actual') = (actual_weight_g IS NOT NULL)),
  CHECK ((weight_source = 'estimated') = (estimated_weight_g IS NOT NULL)),
  CHECK (weight_source <> 'estimated' OR avg_piece_weight_g_used IS NOT NULL),
  CHECK (weight_source <> 'estimated' OR estimated_weight_g = pieces * avg_piece_weight_g_used),
  CHECK (sale_mode <> 'weight' OR weight_source = 'actual'),
  CHECK (sale_mode <> 'piece' OR pieces > 0),
  CHECK (sale_mode = 'amount' OR weight_source <> 'none'),
  CHECK (sale_mode <> 'amount' OR weight_source <> 'estimated'),
  CHECK (sale_mode = 'amount' OR rate_per_kg_paisa IS NOT NULL),
  CHECK (sale_mode = 'amount' OR total_paisa =
         (COALESCE(actual_weight_g, estimated_weight_g) * rate_per_kg_paisa + 500) / 1000)
)""",
  r"""CREATE TABLE customer_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_no TEXT NOT NULL,
  request_id TEXT NOT NULL,
  amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0),
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  bill_id INTEGER NOT NULL REFERENCES customer_transactions(id),
  kind TEXT NOT NULL CHECK (kind IN ('at_sale','later')),
  UNIQUE (receipt_no, bill_id),
  UNIQUE (request_id, bill_id)
)""",
  r"""CREATE TABLE hotels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT,
  address TEXT,
  notes TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
)""",
  r"""CREATE TABLE hotel_transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  hotel_id INTEGER NOT NULL REFERENCES hotels(id),
  chicken_type TEXT NOT NULL CHECK (chicken_type IN ('broiler','sonali')),
  sale_mode TEXT NOT NULL CHECK (sale_mode IN ('weight','piece','amount')),
  pieces INTEGER NOT NULL DEFAULT 0 CHECK (pieces >= 0),
  actual_weight_g INTEGER CHECK (actual_weight_g IS NULL OR actual_weight_g > 0),
  estimated_weight_g INTEGER CHECK (estimated_weight_g IS NULL OR estimated_weight_g > 0),
  weight_source TEXT NOT NULL CHECK (weight_source IN ('actual','estimated','none')),
  avg_piece_weight_g_used INTEGER CHECK (avg_piece_weight_g_used IS NULL OR avg_piece_weight_g_used > 0),
  rate_per_kg_paisa INTEGER CHECK (rate_per_kg_paisa IS NULL OR rate_per_kg_paisa >= 0),
  total_paisa INTEGER NOT NULL CHECK (total_paisa > 0),
  CHECK ((weight_source = 'actual') = (actual_weight_g IS NOT NULL)),
  CHECK ((weight_source = 'estimated') = (estimated_weight_g IS NOT NULL)),
  CHECK (weight_source <> 'estimated' OR avg_piece_weight_g_used IS NOT NULL),
  CHECK (weight_source <> 'estimated' OR estimated_weight_g = pieces * avg_piece_weight_g_used),
  CHECK (sale_mode <> 'weight' OR weight_source = 'actual'),
  CHECK (sale_mode <> 'piece' OR pieces > 0),
  CHECK (sale_mode = 'amount' OR weight_source <> 'none'),
  CHECK (sale_mode <> 'amount' OR weight_source <> 'estimated'),
  CHECK (sale_mode = 'amount' OR rate_per_kg_paisa IS NOT NULL),
  CHECK (sale_mode = 'amount' OR total_paisa =
         (COALESCE(actual_weight_g, estimated_weight_g) * rate_per_kg_paisa + 500) / 1000)
)""",
  r"""CREATE TABLE hotel_payments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_no TEXT NOT NULL,
  request_id TEXT NOT NULL,
  amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0),
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  bill_id INTEGER NOT NULL REFERENCES hotel_transactions(id),
  kind TEXT NOT NULL CHECK (kind IN ('at_sale','later')),
  UNIQUE (receipt_no, bill_id),
  UNIQUE (request_id, bill_id)
)""",
  r"""CREATE TABLE drivers (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
)""",
  r"""CREATE TABLE autos (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  driver_id INTEGER REFERENCES drivers(id),
  standard_deposit_paisa INTEGER NOT NULL CHECK (standard_deposit_paisa >= 0),
  start_date TEXT NOT NULL CHECK (start_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  notes TEXT,
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
)""",
  r"""CREATE TABLE auto_daily_status (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  auto_id INTEGER NOT NULL REFERENCES autos(id),
  driver_id INTEGER REFERENCES drivers(id),
  status TEXT NOT NULL CHECK (status IN ('full','half','sick','broken','leave')),
  standard_deposit_paisa INTEGER NOT NULL CHECK (standard_deposit_paisa >= 0),
  expected_deposit_paisa INTEGER NOT NULL CHECK (expected_deposit_paisa >= 0),
  expected_source TEXT NOT NULL
    CHECK (expected_source IN ('standard','half_percent','zero','manual')),
  half_percent_used INTEGER
    CHECK (half_percent_used IS NULL OR half_percent_used BETWEEN 0 AND 100)
)""",
  r"""CREATE UNIQUE INDEX ux_auto_status_day ON auto_daily_status(auto_id, transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE TABLE auto_deposits (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  receipt_no TEXT NOT NULL,
  request_id TEXT NOT NULL,
  amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0),
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  auto_id INTEGER NOT NULL REFERENCES autos(id),
  driver_id INTEGER REFERENCES drivers(id),
  status_id INTEGER NOT NULL REFERENCES auto_daily_status(id),
  UNIQUE (receipt_no, status_id),
  UNIQUE (request_id, status_id)
)""",
  r"""CREATE TABLE expense_categories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  scope TEXT NOT NULL CHECK (scope IN ('auto','household','general')),
  name TEXT NOT NULL,
  is_builtin INTEGER NOT NULL DEFAULT 0 CHECK (is_builtin IN (0,1)),
  is_active INTEGER NOT NULL DEFAULT 1 CHECK (is_active IN (0,1)),
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  UNIQUE (scope, name)
)""",
  r"""CREATE TABLE auto_expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  auto_id INTEGER NOT NULL REFERENCES autos(id),
  category_id INTEGER NOT NULL REFERENCES expense_categories(id),
  shop_name TEXT,
  amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0)
)""",
  r"""CREATE TABLE household_expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  category_id INTEGER NOT NULL REFERENCES expense_categories(id),
  shop_or_person TEXT,
  amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0)
)""",
  r"""CREATE TABLE general_expenses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  txn_no TEXT NOT NULL UNIQUE,
  request_id TEXT NOT NULL UNIQUE,
  transaction_date TEXT NOT NULL CHECK (transaction_date GLOB '[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9]'),
  transaction_time TEXT NOT NULL CHECK (transaction_time GLOB '[0-9][0-9]:[0-9][0-9]:[0-9][0-9]'),
  notes TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  deleted_at TEXT,
  category_id INTEGER NOT NULL REFERENCES expense_categories(id),
  description TEXT NOT NULL,
  amount_paisa INTEGER NOT NULL CHECK (amount_paisa > 0),
  chicken_related INTEGER NOT NULL DEFAULT 0 CHECK (chicken_related IN (0,1))
)""",
  r"""CREATE TRIGGER trg_customer_no_overpay BEFORE INSERT ON customer_payments
BEGIN
  SELECT RAISE(ABORT, 'OVERPAY') WHERE
    (SELECT COALESCE(SUM(amount_paisa), 0) FROM customer_payments
       WHERE bill_id = NEW.bill_id AND deleted_at IS NULL) + NEW.amount_paisa
    > (SELECT total_paisa FROM customer_transactions WHERE id = NEW.bill_id);
END""",
  r"""CREATE TRIGGER trg_customer_limit_not_below_paid BEFORE UPDATE OF total_paisa ON customer_transactions
BEGIN
  SELECT RAISE(ABORT, 'BELOW_PAID') WHERE NEW.total_paisa <
    (SELECT COALESCE(SUM(amount_paisa), 0) FROM customer_payments
       WHERE bill_id = NEW.id AND deleted_at IS NULL);
END""",
  r"""CREATE TRIGGER trg_customer_no_delete_with_payments BEFORE UPDATE OF deleted_at ON customer_transactions
WHEN NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL
BEGIN
  SELECT RAISE(ABORT, 'HAS_PAYMENTS') WHERE EXISTS
    (SELECT 1 FROM customer_payments WHERE bill_id = NEW.id AND deleted_at IS NULL);
END""",
  r"""CREATE TRIGGER trg_hotel_no_overpay BEFORE INSERT ON hotel_payments
BEGIN
  SELECT RAISE(ABORT, 'OVERPAY') WHERE
    (SELECT COALESCE(SUM(amount_paisa), 0) FROM hotel_payments
       WHERE bill_id = NEW.bill_id AND deleted_at IS NULL) + NEW.amount_paisa
    > (SELECT total_paisa FROM hotel_transactions WHERE id = NEW.bill_id);
END""",
  r"""CREATE TRIGGER trg_hotel_limit_not_below_paid BEFORE UPDATE OF total_paisa ON hotel_transactions
BEGIN
  SELECT RAISE(ABORT, 'BELOW_PAID') WHERE NEW.total_paisa <
    (SELECT COALESCE(SUM(amount_paisa), 0) FROM hotel_payments
       WHERE bill_id = NEW.id AND deleted_at IS NULL);
END""",
  r"""CREATE TRIGGER trg_hotel_no_delete_with_payments BEFORE UPDATE OF deleted_at ON hotel_transactions
WHEN NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL
BEGIN
  SELECT RAISE(ABORT, 'HAS_PAYMENTS') WHERE EXISTS
    (SELECT 1 FROM hotel_payments WHERE bill_id = NEW.id AND deleted_at IS NULL);
END""",
  r"""CREATE TRIGGER trg_auto_no_overpay BEFORE INSERT ON auto_deposits
BEGIN
  SELECT RAISE(ABORT, 'OVERPAY') WHERE
    (SELECT COALESCE(SUM(amount_paisa), 0) FROM auto_deposits
       WHERE status_id = NEW.status_id AND deleted_at IS NULL) + NEW.amount_paisa
    > (SELECT expected_deposit_paisa FROM auto_daily_status WHERE id = NEW.status_id);
END""",
  r"""CREATE TRIGGER trg_auto_limit_not_below_paid BEFORE UPDATE OF expected_deposit_paisa ON auto_daily_status
BEGIN
  SELECT RAISE(ABORT, 'BELOW_PAID') WHERE NEW.expected_deposit_paisa <
    (SELECT COALESCE(SUM(amount_paisa), 0) FROM auto_deposits
       WHERE status_id = NEW.id AND deleted_at IS NULL);
END""",
  r"""CREATE TRIGGER trg_auto_no_delete_with_payments BEFORE UPDATE OF deleted_at ON auto_daily_status
WHEN NEW.deleted_at IS NOT NULL AND OLD.deleted_at IS NULL
BEGIN
  SELECT RAISE(ABORT, 'HAS_PAYMENTS') WHERE EXISTS
    (SELECT 1 FROM auto_deposits WHERE status_id = NEW.id AND deleted_at IS NULL);
END""",
  r"""CREATE INDEX ix_purchases_date ON purchases(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_retail_sales_date ON retail_sales(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_customer_transactions_date ON customer_transactions(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_customer_payments_date ON customer_payments(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_hotel_transactions_date ON hotel_transactions(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_hotel_payments_date ON hotel_payments(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_auto_daily_status_date ON auto_daily_status(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_auto_deposits_date ON auto_deposits(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_auto_expenses_date ON auto_expenses(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_household_expenses_date ON household_expenses(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_general_expenses_date ON general_expenses(transaction_date) WHERE deleted_at IS NULL""",
  r"""CREATE INDEX ix_purchases_dealer_id ON purchases(dealer_id)""",
  r"""CREATE INDEX ix_customer_transactions_customer_id ON customer_transactions(customer_id)""",
  r"""CREATE INDEX ix_customer_payments_bill_id ON customer_payments(bill_id)""",
  r"""CREATE INDEX ix_hotel_transactions_hotel_id ON hotel_transactions(hotel_id)""",
  r"""CREATE INDEX ix_hotel_payments_bill_id ON hotel_payments(bill_id)""",
  r"""CREATE INDEX ix_autos_driver_id ON autos(driver_id)""",
  r"""CREATE INDEX ix_auto_daily_status_auto_id ON auto_daily_status(auto_id)""",
  r"""CREATE INDEX ix_auto_deposits_status_id ON auto_deposits(status_id)""",
  r"""CREATE INDEX ix_auto_deposits_auto_id ON auto_deposits(auto_id)""",
  r"""CREATE INDEX ix_auto_expenses_auto_id ON auto_expenses(auto_id)""",
  r"""CREATE INDEX ix_auto_expenses_category_id ON auto_expenses(category_id)""",
  r"""CREATE INDEX ix_household_expenses_category_id ON household_expenses(category_id)""",
  r"""CREATE INDEX ix_general_expenses_category_id ON general_expenses(category_id)""",
  r"""CREATE INDEX ix_customers_name ON customers(name)""",
  r"""CREATE INDEX ix_customers_phone ON customers(phone)""",
  r"""CREATE INDEX ix_hotels_name ON hotels(name)""",
  r"""CREATE INDEX ix_chicken_rates_lookup ON chicken_rates(chicken_type, transaction_date, transaction_time, id)""",
  r"""CREATE INDEX ix_audit_log_record ON audit_log(table_name, record_id)""",
];
