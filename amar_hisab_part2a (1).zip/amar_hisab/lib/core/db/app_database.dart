import 'package:amar_hisab/core/db/db_errors.dart';
import 'package:amar_hisab/core/db/migration_runner.dart';
import 'package:amar_hisab/core/errors/app_exception.dart';
import 'package:amar_hisab/core/time/app_clock.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// The single entry point to the SQLite database.
///
/// - Opens the file, switches on foreign-key enforcement and runs migrations.
/// - [write] runs several statements in one all-or-nothing transaction.
/// - Database failures are translated into [AppException]s with plain English
///   messages, so screens never show raw SQL errors.
final class AppDatabase {
  AppDatabase._(this._db, this.path);

  /// Current schema version. Must equal `MigrationRunner.latestVersion`.
  static const int schemaVersion = 1;

  /// File name of the production database.
  static const String fileName = 'amar_hisab.db';

  final Database _db;

  /// Where the database lives on disk (or ':memory:' in tests).
  final String path;

  /// The default production location, inside the app's private databases folder.
  static Future<String> defaultPath() async =>
      p.join(await getDatabasesPath(), fileName);

  /// Opens (and if needed creates or upgrades) the database at [path].
  ///
  /// Pass [factory] to use a different SQLite backend, for example
  /// `databaseFactoryFfi` in tests on a computer.
  static Future<AppDatabase> open({
    required String path,
    required AppClock clock,
    DatabaseFactory? factory,
  }) async {
    assert(
      schemaVersion == MigrationRunner.latestVersion,
      'schemaVersion and the migration list are out of sync',
    );
    final databaseFactoryToUse = factory ?? databaseFactory;
    try {
      final db = await databaseFactoryToUse.openDatabase(
        path,
        options: OpenDatabaseOptions(
          version: schemaVersion,
          singleInstance: path != inMemoryDatabasePath,
          onConfigure: (db) => db.execute('PRAGMA foreign_keys = ON'),
          onCreate: (db, version) =>
              MigrationRunner.onCreate(db, version, clock.now().toUtc()),
          onUpgrade: (db, oldVersion, newVersion) =>
              MigrationRunner.onUpgrade(db, oldVersion, newVersion, clock.now().toUtc()),
          onDowngrade: (db, oldVersion, newVersion) => throw const BackupException(
            'This data was created by a newer version of the app. '
            'Please update the app first.',
          ),
        ),
      );
      return AppDatabase._(db, path);
    } on AppException {
      rethrow;
    } catch (error) {
      throw DatabaseFailure('The database could not be opened.', cause: error);
    }
  }

  /// The underlying connection, for backup and for tests that need to look at
  /// raw rows. Application code should use [read] and [write].
  Database get raw => _db;

  /// Runs [action] against the database for reading.
  Future<T> read<T>(Future<T> Function(DatabaseExecutor db) action) =>
      _guard(() => action(_db));

  /// Runs [action] inside one SQL transaction: either every statement inside
  /// succeeds, or none of them is kept.
  ///
  /// Inside [action] use only the `txn` you are given, never the database
  /// itself, or the call will wait on itself forever.
  Future<T> write<T>(Future<T> Function(Transaction txn) action) =>
      _guard(() => _db.transaction<T>(action));

  /// The schema version stored in the file (`PRAGMA user_version`).
  Future<int> userVersion() async {
    final rows = await _db.rawQuery('PRAGMA user_version');
    return rows.first.values.first! as int;
  }

  Future<void> close() => _db.close();

  Future<T> _guard<T>(Future<T> Function() action) async {
    try {
      return await action();
    } on AppException {
      rethrow;
    } on DatabaseException catch (error) {
      throw DbErrors.toAppException(error);
    }
  }
}
