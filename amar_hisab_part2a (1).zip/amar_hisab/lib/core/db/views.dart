import 'package:sqflite/sqflite.dart';

/// Read-only views that derive "paid" and "due" from the payment rows.
///
/// Nothing stores a running balance anywhere: `paid = sum of active payments`
/// and `due = total - paid`. Views are dropped and recreated after every
/// migration, so changing a view never needs its own migration step.
abstract final class Views {
  static const List<String> names = <String>['v_customer_bills', 'v_hotel_bills', 'v_auto_days'];

  static const List<String> createStatements = <String>[
    r"""CREATE VIEW v_customer_bills AS
SELECT t.*,
       COALESCE(p.paid, 0) AS paid_paisa,
       t.total_paisa - COALESCE(p.paid, 0) AS due_paisa
FROM customer_transactions t
LEFT JOIN (SELECT bill_id, SUM(amount_paisa) AS paid
           FROM customer_payments WHERE deleted_at IS NULL GROUP BY bill_id) p
  ON p.bill_id = t.id
WHERE t.deleted_at IS NULL""",
    r"""CREATE VIEW v_hotel_bills AS
SELECT t.*,
       COALESCE(p.paid, 0) AS paid_paisa,
       t.total_paisa - COALESCE(p.paid, 0) AS due_paisa
FROM hotel_transactions t
LEFT JOIN (SELECT bill_id, SUM(amount_paisa) AS paid
           FROM hotel_payments WHERE deleted_at IS NULL GROUP BY bill_id) p
  ON p.bill_id = t.id
WHERE t.deleted_at IS NULL""",
    r"""CREATE VIEW v_auto_days AS
SELECT s.*,
       COALESCE(d.received, 0) AS received_paisa,
       s.expected_deposit_paisa - COALESCE(d.received, 0) AS due_paisa
FROM auto_daily_status s
LEFT JOIN (SELECT status_id, SUM(amount_paisa) AS received
           FROM auto_deposits WHERE deleted_at IS NULL GROUP BY status_id) d
  ON d.status_id = s.id
WHERE s.deleted_at IS NULL""",
  ];

  static Future<void> recreate(DatabaseExecutor db) async {
    for (final name in names) {
      await db.execute('DROP VIEW IF EXISTS $name');
    }
    for (final statement in createStatements) {
      await db.execute(statement);
    }
  }
}
