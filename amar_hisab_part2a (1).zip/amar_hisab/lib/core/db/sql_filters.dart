/// Builds the WHERE part of list queries (search, date range, filters).
///
/// Values are never pasted into the SQL text; they travel as `?` parameters,
/// so a name containing a quote or a percent sign can never break a query.
/// Column names passed in come from code, never from user input.
final class WhereBuilder {
  final List<String> _clauses = <String>[];
  final List<Object?> _arguments = <Object?>[];

  /// The clause text, ready to put after `WHERE`. Always valid SQL.
  String get clause => _clauses.isEmpty ? '1 = 1' : _clauses.join(' AND ');

  /// Values for the `?` placeholders in [clause], in order.
  List<Object?> get arguments => List<Object?>.unmodifiable(_arguments);

  bool get isEmpty => _clauses.isEmpty;

  /// Adds a raw condition such as `deleted_at IS NULL` or `amount_paisa > ?`.
  WhereBuilder add(String condition, [List<Object?> params = const <Object?>[]]) {
    _clauses.add('($condition)');
    _arguments.addAll(params);
    return this;
  }

  /// Adds `column = value`, but only when [value] is not null.
  WhereBuilder equalsIfSet(String column, Object? value) {
    if (value == null) return this;
    return add('$column = ?', <Object?>[value]);
  }

  /// Restricts a `YYYY-MM-DD` [column] to an inclusive date range.
  /// Either end may be null for an open-ended range.
  WhereBuilder dateRange(String column, {String? from, String? to}) {
    if (from != null) add('$column >= ?', <Object?>[from]);
    if (to != null) add('$column <= ?', <Object?>[to]);
    return this;
  }

  /// Matches rows where ANY of [columns] contains [query] (case-insensitive
  /// for English letters). Blank queries add nothing.
  WhereBuilder searchAny(List<String> columns, String? query) {
    final text = query?.trim() ?? '';
    if (text.isEmpty || columns.isEmpty) return this;
    final pattern = '%${escapeLike(text)}%';
    final parts = columns.map((column) => "$column LIKE ? ESCAPE '\\'").join(' OR ');
    return add(parts, List<Object?>.filled(columns.length, pattern));
  }

  /// Escapes `%`, `_` and `\` so they match literally inside a LIKE pattern.
  static String escapeLike(String input) {
    return input
        .replaceAll(r'\', r'\\')
        .replaceAll('%', r'\%')
        .replaceAll('_', r'\_');
  }
}
