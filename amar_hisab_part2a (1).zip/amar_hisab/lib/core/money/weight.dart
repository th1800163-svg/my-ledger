/// A weight stored as an integer number of grams.
///
/// Integer grams avoid every floating-point rounding problem: 2.5 kg is
/// exactly 2500 g, and 0.1 kg + 0.2 kg is exactly 300 g.
final class Weight implements Comparable<Weight> {
  const Weight(this.grams);

  /// Creates a weight from whole kilograms.
  const Weight.fromKg(int kg) : grams = kg * 1000;

  final int grams;

  static const Weight zero = Weight(0);

  bool get isZero => grams == 0;
  bool get isPositive => grams > 0;
  bool get isNegative => grams < 0;

  Weight operator +(Weight other) => Weight(grams + other.grams);
  Weight operator -(Weight other) => Weight(grams - other.grams);

  /// Multiplies by a whole number, for example pieces × average piece weight.
  Weight times(int count) => Weight(grams * count);

  bool operator <(Weight other) => grams < other.grams;
  bool operator <=(Weight other) => grams <= other.grams;
  bool operator >(Weight other) => grams > other.grams;
  bool operator >=(Weight other) => grams >= other.grams;

  /// Kilograms as plain text, with no unit and no digit grouping.
  ///
  /// 2500 g → "2.5", 2000 g → "2", 1234 g → "1.234", 50 g → "0.05".
  /// Also used to pre-fill weight fields when editing.
  String toKgString() {
    final sign = grams < 0 ? '-' : '';
    final absolute = grams.abs();
    final whole = absolute ~/ 1000;
    final fraction = absolute % 1000;
    if (fraction == 0) return '$sign$whole';
    final digits = fraction.toString().padLeft(3, '0').replaceFirst(RegExp(r'0+$'), '');
    return '$sign$whole.$digits';
  }

  @override
  int compareTo(Weight other) => grams.compareTo(other.grams);

  @override
  bool operator ==(Object other) => other is Weight && other.grams == grams;

  @override
  int get hashCode => grams.hashCode;

  @override
  String toString() => 'Weight(${toKgString()} kg)';
}
