import 'package:amar_hisab/core/text/digit_normalizer.dart';

/// Why a number could not be parsed.
enum DecimalParseError {
  empty,
  invalidFormat,
  negative,
  tooManyDecimals,
  tooLarge,
}

/// Result of [DecimalParser.parseScaled]: either [scaled] or an [error].
final class DecimalParseResult {
  const DecimalParseResult.ok(int this.scaled) : error = null;
  const DecimalParseResult.failure(DecimalParseError this.error) : scaled = null;

  /// The value multiplied by 10^scale, for example "12.5" with scale 2 → 1250.
  final int? scaled;
  final DecimalParseError? error;

  bool get isOk => error == null;
}

/// Parses typed decimal numbers into integers, without ever using `double`.
///
/// `parseScaled('12.5', scale: 2)` returns 1250 (paisa) and
/// `parseScaled('2.250', scale: 3)` returns 2250 (grams). Because the work is
/// done on the digits themselves there is no floating-point rounding error.
abstract final class DecimalParser {
  /// More integer digits than this are rejected before they can overflow.
  static const int maxIntegerDigits = 12;

  static final RegExp _pattern = RegExp(r'^(\d+\.?\d*|\.\d+)$');
  static final RegExp _trailingZeros = RegExp(r'0+$');
  static final RegExp _leadingZeros = RegExp(r'^0+(?=\d)');
  static final RegExp _digitsOnly = RegExp(r'^\d+$');

  static DecimalParseResult parseScaled(String? raw, {required int scale}) {
    assert(scale >= 0 && scale <= 6, 'scale must be between 0 and 6');

    final text = normalizeNumberInput(raw ?? '');
    if (text.isEmpty) {
      return const DecimalParseResult.failure(DecimalParseError.empty);
    }
    if (text.startsWith('-')) {
      return const DecimalParseResult.failure(DecimalParseError.negative);
    }
    if (!_pattern.hasMatch(text)) {
      return const DecimalParseResult.failure(DecimalParseError.invalidFormat);
    }

    final dot = text.indexOf('.');
    var integerPart = dot < 0 ? text : text.substring(0, dot);
    var fractionPart = dot < 0 ? '' : text.substring(dot + 1);

    // "12.500" and "12.5" are the same number, so trailing zeros never count
    // as extra decimal places.
    fractionPart = fractionPart.replaceFirst(_trailingZeros, '');
    if (fractionPart.length > scale) {
      return const DecimalParseResult.failure(DecimalParseError.tooManyDecimals);
    }

    integerPart = integerPart.replaceFirst(_leadingZeros, '');
    if (integerPart.length > maxIntegerDigits) {
      return const DecimalParseResult.failure(DecimalParseError.tooLarge);
    }

    final whole = integerPart.isEmpty ? 0 : int.parse(integerPart);
    final paddedFraction = fractionPart.padRight(scale, '0');
    final fraction = paddedFraction.isEmpty ? 0 : int.parse(paddedFraction);

    var factor = 1;
    for (var i = 0; i < scale; i++) {
      factor *= 10;
    }
    return DecimalParseResult.ok(whole * factor + fraction);
  }

  /// Parses a whole number (no decimal point allowed).
  static DecimalParseResult parseWhole(String? raw) {
    final text = normalizeNumberInput(raw ?? '');
    if (text.isEmpty) {
      return const DecimalParseResult.failure(DecimalParseError.empty);
    }
    if (text.startsWith('-')) {
      return const DecimalParseResult.failure(DecimalParseError.negative);
    }
    if (!_digitsOnly.hasMatch(text)) {
      return const DecimalParseResult.failure(DecimalParseError.invalidFormat);
    }
    final trimmed = text.replaceFirst(_leadingZeros, '');
    if (trimmed.length > maxIntegerDigits) {
      return const DecimalParseResult.failure(DecimalParseError.tooLarge);
    }
    return DecimalParseResult.ok(int.parse(trimmed));
  }
}
