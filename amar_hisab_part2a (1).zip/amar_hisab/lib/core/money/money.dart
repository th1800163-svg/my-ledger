import 'package:amar_hisab/core/money/weight.dart';

/// An amount of Bangladeshi Taka stored as an integer number of paisa.
///
/// 1 Taka = 100 paisa. Using integers means 0.1 + 0.2 is exactly 0.3 and
/// totals never drift because of floating-point rounding.
final class Money implements Comparable<Money> {
  const Money(this.paisa);

  /// Creates an amount from whole Taka.
  const Money.fromTaka(int taka) : paisa = taka * 100;

  final int paisa;

  static const Money zero = Money(0);

  bool get isZero => paisa == 0;
  bool get isPositive => paisa > 0;
  bool get isNegative => paisa < 0;

  Money operator +(Money other) => Money(paisa + other.paisa);
  Money operator -(Money other) => Money(paisa - other.paisa);
  Money operator -() => Money(-paisa);

  /// Multiplies by a whole number (for example price × quantity of items).
  Money times(int factor) => Money(paisa * factor);

  bool operator <(Money other) => paisa < other.paisa;
  bool operator <=(Money other) => paisa <= other.paisa;
  bool operator >(Money other) => paisa > other.paisa;
  bool operator >=(Money other) => paisa >= other.paisa;

  static Money min(Money a, Money b) => a.paisa <= b.paisa ? a : b;
  static Money max(Money a, Money b) => a.paisa >= b.paisa ? a : b;

  /// Adds up a collection of amounts. An empty collection gives [zero].
  static Money sum(Iterable<Money> amounts) {
    var total = 0;
    for (final amount in amounts) {
      total += amount.paisa;
    }
    return Money(total);
  }

  /// Rule R1: the price of [weight] at [ratePerKg].
  ///
  /// `amount = (grams × paisa-per-kg + 500) ÷ 1000`, using integer division, so
  /// the result is rounded half up to the nearest paisa.
  /// Example: 20 kg at ৳350/kg → (20000 × 35000 + 500) ÷ 1000 = 700000 paisa = ৳7,000.
  ///
  /// Both inputs must be zero or positive; a negative weight or rate is a
  /// programming error because the validators never let one through.
  static Money forWeight(Weight weight, Money ratePerKg) {
    assert(weight.grams >= 0 && ratePerKg.paisa >= 0, 'weight and rate must not be negative');
    return Money((weight.grams * ratePerKg.paisa + 500) ~/ 1000);
  }

  /// [percent] percent of this amount, rounded half up to the nearest paisa.
  ///
  /// Used for the configurable half-time deposit: standard × 50 ÷ 100.
  /// Only for zero or positive amounts and percentages.
  Money percentage(int percent) {
    assert(paisa >= 0 && percent >= 0, 'amount and percent must not be negative');
    return Money((paisa * percent + 50) ~/ 100);
  }

  /// Plain text for pre-filling a text field: "7000" or "7000.50".
  /// Always Latin digits, no symbol and no grouping commas.
  String toInputString() {
    final sign = paisa < 0 ? '-' : '';
    final absolute = paisa.abs();
    final taka = absolute ~/ 100;
    final cents = absolute % 100;
    if (cents == 0) return '$sign$taka';
    return '$sign$taka.${cents.toString().padLeft(2, '0')}';
  }

  @override
  int compareTo(Money other) => paisa.compareTo(other.paisa);

  @override
  bool operator ==(Object other) => other is Money && other.paisa == paisa;

  @override
  int get hashCode => paisa.hashCode;

  @override
  String toString() => 'Money($paisa paisa)';
}
