import 'package:amar_hisab/core/money/decimal_parser.dart';
import 'package:amar_hisab/core/money/money.dart';
import 'package:amar_hisab/core/money/weight.dart';
import 'package:amar_hisab/core/text/app_strings.dart';
import 'package:amar_hisab/core/text/money_format.dart';
import 'package:amar_hisab/core/validation/bd_phone.dart';
import 'package:amar_hisab/core/validation/limits.dart';
import 'package:amar_hisab/core/validation/validated.dart';

/// A validator in the shape Flutter's `TextFormField.validator` expects.
typedef FieldValidator = String? Function(String? value);

/// All input validation in one place (rule R13).
///
/// Every method accepts the raw text the owner typed, understands Latin and
/// Bengali digits, and returns either a clean value or an English message.
abstract final class Validators {
  // ---- money ----------------------------------------------------------

  /// A money amount with at most 2 decimal places.
  ///
  /// - [required] false: an empty field is accepted and means zero.
  /// - [allowZero] true: typing 0 is accepted (for example transport cost).
  static Validated<Money> money(
    String? raw, {
    String label = 'Amount',
    bool required = true,
    bool allowZero = false,
    Money max = Limits.maxAmount,
  }) {
    final parsed = DecimalParser.parseScaled(raw, scale: 2);
    if (!required && parsed.error == DecimalParseError.empty) {
      return const Valid<Money>(Money.zero);
    }
    final problem = _decimalProblem(parsed, label, decimals: 2);
    if (problem != null) return Invalid<Money>(problem);

    final value = Money(parsed.scaled!);
    if (value.isZero && !allowZero && required) {
      return Invalid<Money>(ValidationText.greaterThanZero(label));
    }
    if (value > max) {
      return Invalid<Money>(
        ValidationText.maxAllowed(label, MoneyFormat.standard.format(max)),
      );
    }
    return Valid<Money>(value);
  }

  /// A price per kg: greater than zero, at most [Limits.maxRatePerKg].
  static Validated<Money> ratePerKg(String? raw, {String label = 'Rate per kg'}) =>
      money(raw, label: label, max: Limits.maxRatePerKg);

  // ---- weight ---------------------------------------------------------

  /// A weight typed in kilograms (up to 3 decimals = whole grams), greater
  /// than zero.
  static Validated<Weight> weightKg(
    String? raw, {
    String label = 'Weight',
    Weight max = Limits.maxWeight,
  }) {
    final parsed = DecimalParser.parseScaled(raw, scale: 3);
    final problem = _decimalProblem(parsed, label, decimals: 3);
    if (problem != null) return Invalid<Weight>(problem);

    final value = Weight(parsed.scaled!);
    if (value.isZero) return Invalid<Weight>(ValidationText.greaterThanZero(label));
    if (value > max) {
      return Invalid<Weight>(
        ValidationText.maxAllowed(label, '${max.toKgString()} ${AppStrings.kg}'),
      );
    }
    return Valid<Weight>(value);
  }

  /// Like [weightKg], but an empty field is fine and gives `null`.
  static Validated<Weight?> optionalWeightKg(
    String? raw, {
    String label = 'Weight',
    Weight max = Limits.maxWeight,
  }) {
    if (_isBlank(raw)) return const Valid<Weight?>(null);
    final result = weightKg(raw, label: label, max: max);
    final value = result.valueOrNull;
    if (value == null) return Invalid<Weight?>(result.errorOrNull!);
    return Valid<Weight?>(value);
  }

  // ---- counts ---------------------------------------------------------

  /// A whole number of pieces.
  ///
  /// - [required] false: an empty field is accepted and means zero.
  /// - [allowZero] false (default): zero is rejected when something was typed.
  static Validated<int> pieces(
    String? raw, {
    String label = 'Pieces',
    bool required = true,
    bool allowZero = false,
  }) {
    final parsed = DecimalParser.parseWhole(raw);
    if (!required && parsed.error == DecimalParseError.empty) {
      return const Valid<int>(0);
    }
    switch (parsed.error) {
      case null:
        break;
      case DecimalParseError.empty:
        return Invalid<int>(ValidationText.required(label));
      case DecimalParseError.negative:
        return Invalid<int>(ValidationText.negative(label));
      case DecimalParseError.invalidFormat:
        return Invalid<int>(ValidationText.notWholeNumber(label));
      case DecimalParseError.tooManyDecimals:
        return Invalid<int>(ValidationText.notWholeNumber(label));
      case DecimalParseError.tooLarge:
        return Invalid<int>(ValidationText.tooLarge(label));
    }
    final value = parsed.scaled!;
    if (value == 0 && !allowZero) {
      return Invalid<int>(ValidationText.greaterThanZero(label));
    }
    if (value > Limits.maxPieces) {
      return Invalid<int>(ValidationText.maxAllowed(label, '${Limits.maxPieces}'));
    }
    return Valid<int>(value);
  }

  /// A whole-number percentage from 0 to 100.
  static Validated<int> percent(String? raw, {String label = 'Percentage'}) {
    final parsed = DecimalParser.parseWhole(raw);
    switch (parsed.error) {
      case null:
        break;
      case DecimalParseError.empty:
        return Invalid<int>(ValidationText.required(label));
      case DecimalParseError.negative:
        return Invalid<int>(ValidationText.negative(label));
      case DecimalParseError.invalidFormat:
      case DecimalParseError.tooManyDecimals:
        return Invalid<int>(ValidationText.notWholeNumber(label));
      case DecimalParseError.tooLarge:
        return Invalid<int>(ValidationText.percentRange(label));
    }
    final value = parsed.scaled!;
    if (value > Limits.maxPercent) {
      return Invalid<int>(ValidationText.percentRange(label));
    }
    return Valid<int>(value);
  }

  // ---- text -----------------------------------------------------------

  /// A required name. Surrounding spaces are removed and runs of spaces
  /// inside the name are collapsed to one.
  static Validated<String> name(String? raw, {String label = 'Name'}) {
    final cleaned = _collapseSpaces(raw ?? '');
    if (cleaned.isEmpty) return Invalid<String>(ValidationText.required(label));
    if (cleaned.length > Limits.maxNameLength) {
      return Invalid<String>(ValidationText.nameTooLong(label, Limits.maxNameLength));
    }
    return Valid<String>(cleaned);
  }

  /// Optional free text (notes, address). Empty becomes `null`.
  static Validated<String?> optionalText(
    String? raw, {
    String label = 'Notes',
    int maxLength = Limits.maxNotesLength,
  }) {
    final cleaned = (raw ?? '').trim();
    if (cleaned.isEmpty) return const Valid<String?>(null);
    if (cleaned.length > maxLength) {
      return Invalid<String?>(ValidationText.textTooLong(label, maxLength));
    }
    return Valid<String?>(cleaned);
  }

  /// An optional phone number, returned in canonical form (`01712345678`).
  static Validated<String?> phone(String? raw) {
    if (_isBlank(raw)) return const Valid<String?>(null);
    final normalized = BdPhone.normalize(raw!);
    if (normalized == null) return const Invalid<String?>(ValidationText.invalidPhone);
    return Valid<String?>(normalized);
  }

  // ---- dates ----------------------------------------------------------

  /// A transaction date and time must not be in the future.
  /// One minute of slack covers a clock that is a few seconds fast.
  static Validated<DateTime> notInFuture(DateTime value, DateTime now) {
    if (value.isAfter(now.add(const Duration(minutes: 1)))) {
      return const Invalid<DateTime>(ValidationText.futureDate);
    }
    return Valid<DateTime>(value);
  }

  // ---- payments -------------------------------------------------------

  /// Money received now ("Receive" button): more than zero and no more than
  /// what is still [due]. Advance payments are not supported in version 1.
  static Validated<Money> receiveAmount(Money amount, Money due) {
    if (due <= Money.zero) {
      return const Invalid<Money>(ValidationText.nothingDue);
    }
    if (amount <= Money.zero) {
      return Invalid<Money>(ValidationText.greaterThanZero('Amount'));
    }
    if (amount > due) {
      return Invalid<Money>(
        ValidationText.receiveMoreThanDue(MoneyFormat.standard.format(due)),
      );
    }
    return Valid<Money>(amount);
  }

  /// The "paid now" amount typed while recording a sale: from zero up to the
  /// bill [total].
  static Validated<Money> paidAtSale(Money paid, Money total) {
    if (paid.isNegative) {
      return Invalid<Money>(ValidationText.negative('Paid amount'));
    }
    if (paid > total) {
      return Invalid<Money>(
        ValidationText.paidMoreThanTotal(MoneyFormat.standard.format(total)),
      );
    }
    return Valid<Money>(paid);
  }

  // ---- form-field adapters ---------------------------------------------

  static FieldValidator moneyField({
    String label = 'Amount',
    bool required = true,
    bool allowZero = false,
    Money max = Limits.maxAmount,
  }) =>
      (value) => money(value, label: label, required: required, allowZero: allowZero, max: max)
          .errorOrNull;

  static FieldValidator rateField({String label = 'Rate per kg'}) =>
      (value) => ratePerKg(value, label: label).errorOrNull;

  static FieldValidator weightField({String label = 'Weight'}) =>
      (value) => weightKg(value, label: label).errorOrNull;

  static FieldValidator optionalWeightField({String label = 'Weight'}) =>
      (value) => optionalWeightKg(value, label: label).errorOrNull;

  static FieldValidator piecesField({
    String label = 'Pieces',
    bool required = true,
    bool allowZero = false,
  }) =>
      (value) => pieces(value, label: label, required: required, allowZero: allowZero).errorOrNull;

  static FieldValidator percentField({String label = 'Percentage'}) =>
      (value) => percent(value, label: label).errorOrNull;

  static FieldValidator nameField({String label = 'Name'}) =>
      (value) => name(value, label: label).errorOrNull;

  static FieldValidator phoneField() => (value) => phone(value).errorOrNull;

  static FieldValidator notesField({String label = 'Notes'}) =>
      (value) => optionalText(value, label: label).errorOrNull;

  // ---- helpers --------------------------------------------------------

  static bool _isBlank(String? raw) => raw == null || raw.trim().isEmpty;

  static String _collapseSpaces(String raw) =>
      raw.trim().replaceAll(RegExp(r'\s+'), ' ');

  /// Maps a parse failure to a message, or `null` when parsing succeeded.
  static String? _decimalProblem(
    DecimalParseResult result,
    String label, {
    required int decimals,
  }) {
    switch (result.error) {
      case null:
        return null;
      case DecimalParseError.empty:
        return ValidationText.required(label);
      case DecimalParseError.invalidFormat:
        return ValidationText.notANumber(label);
      case DecimalParseError.negative:
        return ValidationText.negative(label);
      case DecimalParseError.tooManyDecimals:
        return ValidationText.tooManyDecimals(label, decimals);
      case DecimalParseError.tooLarge:
        return ValidationText.tooLarge(label);
    }
  }
}
