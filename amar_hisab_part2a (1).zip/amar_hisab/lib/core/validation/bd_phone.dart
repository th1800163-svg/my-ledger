import 'package:amar_hisab/core/text/digit_normalizer.dart';

/// Phone numbers in Bangladeshi formats.
///
/// A number is stored in one canonical form so that search works no matter
/// how it was typed: `01712345678`, `01712 345 678`, `+8801712345678` and
/// `8801712345678` all become `01712345678`.
abstract final class BdPhone {
  static final RegExp _separators = RegExp(r'[\s\-().]');

  /// Mobile: 01 + operator digit 3-9 + 8 more digits (11 digits in total).
  static final RegExp _mobile = RegExp(r'^01[3-9]\d{8}$');

  /// Landline: area code starting 02-09, 8 to 11 digits in total. Numbers
  /// beginning "01" are mobile-only, so they never count as landlines.
  static final RegExp _landline = RegExp(r'^0[2-9]\d{6,9}$');

  /// Returns the canonical number, or `null` if [raw] is not a valid
  /// Bangladeshi mobile or landline number.
  static String? normalize(String raw) {
    var text = normalizeDigits(raw).replaceAll(_separators, '');
    if (text.startsWith('+')) text = text.substring(1);
    if (text.startsWith('880') && text.length == 13) {
      text = '0${text.substring(3)}';
    }
    if (_mobile.hasMatch(text) || _landline.hasMatch(text)) return text;
    return null;
  }

  static bool isValid(String raw) => normalize(raw) != null;

  /// `tel:` URI for the phone dialer.
  static Uri dialerUri(String canonicalNumber) =>
      Uri(scheme: 'tel', path: canonicalNumber);
}
