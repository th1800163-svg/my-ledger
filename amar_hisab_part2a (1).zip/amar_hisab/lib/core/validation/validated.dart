import 'package:amar_hisab/core/errors/app_exception.dart';

/// The result of validating one input: either a clean value or a message.
///
/// Validators never throw for bad input; they return [Invalid] with text that
/// can be shown under the field. Service code that must stop on bad input
/// calls [requireValue], which throws a [ValidationException].
sealed class Validated<T> {
  const Validated();

  bool get isValid => this is Valid<T>;

  /// The cleaned value, or `null` if the input was invalid.
  T? get valueOrNull {
    final self = this;
    return self is Valid<T> ? self.value : null;
  }

  /// The message to show, or `null` if the input was valid.
  String? get errorOrNull {
    final self = this;
    return self is Invalid<T> ? self.message : null;
  }

  /// The cleaned value; throws [ValidationException] if invalid.
  T get requireValue {
    final self = this;
    if (self is Valid<T>) return self.value;
    throw ValidationException((self as Invalid<T>).message);
  }
}

final class Valid<T> extends Validated<T> {
  const Valid(this.value);

  final T value;
}

final class Invalid<T> extends Validated<T> {
  const Invalid(this.message);

  final String message;
}
