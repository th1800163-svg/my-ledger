import 'package:amar_hisab/core/money/money.dart';
import 'package:amar_hisab/core/money/weight.dart';

/// Upper bounds that catch typing mistakes (an extra zero, a pasted number).
///
/// They are generous for a small business; their job is to stop an accidental
/// ৳10,00,00,000,000 from reaching the books, not to restrict real trade.
abstract final class Limits {
  /// Largest single amount: ৳1 crore.
  static const Money maxAmount = Money(1000000000);

  /// Largest rate per kg: ৳10,000.
  static const Money maxRatePerKg = Money(1000000);

  /// Largest weight in a single entry: 50,000 kg.
  static const Weight maxWeight = Weight(50000000);

  /// Largest number of pieces in a single entry.
  static const int maxPieces = 100000;

  static const int maxNameLength = 80;
  static const int maxNotesLength = 500;
  static const int maxPercent = 100;
}
