import 'package:amar_hisab/core/money/money.dart';
import 'package:amar_hisab/core/text/money_format.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  const southAsian = MoneyFormat();
  const international = MoneyFormat(grouping: NumberGrouping.international);

  group('South Asian grouping (lakh / crore)', () {
    test('small amounts', () {
      expect(southAsian.format(Money.fromTaka(0)), '৳0');
      expect(southAsian.format(Money.fromTaka(999)), '৳999');
      expect(southAsian.format(Money.fromTaka(1000)), '৳1,000');
      expect(southAsian.format(Money.fromTaka(7000)), '৳7,000');
    });

    test('lakh and crore', () {
      expect(southAsian.format(Money.fromTaka(100000)), '৳1,00,000');
      expect(southAsian.format(Money.fromTaka(1250000)), '৳12,50,000');
      expect(southAsian.format(Money.fromTaka(10000000)), '৳1,00,00,000');
    });

    test('paisa appear only when present', () {
      expect(southAsian.format(const Money(125000050)), '৳12,50,000.50');
      expect(southAsian.format(const Money(5)), '৳0.05');
      expect(southAsian.format(const Money(700050)), '৳7,000.50');
    });
  });

  group('International grouping', () {
    test('thousands', () {
      expect(international.format(Money.fromTaka(1250000)), '৳1,250,000');
      expect(international.format(const Money(125000050)), '৳1,250,000.50');
      expect(international.format(Money.fromTaka(999)), '৳999');
    });
  });

  group('Options', () {
    test('negative amounts put the sign first', () {
      expect(southAsian.format(Money.fromTaka(-1200)), '-৳1,200');
    });

    test('fixedDecimals always shows two decimals', () {
      expect(southAsian.format(Money.fromTaka(7000), fixedDecimals: true), '৳7,000.00');
    });

    test('withSymbol false gives only the number', () {
      expect(southAsian.format(Money.fromTaka(7000), withSymbol: false), '7,000');
    });

    test('text symbols are followed by a space', () {
      expect(const MoneyFormat(symbol: 'Tk').format(Money.fromTaka(7000)), 'Tk 7,000');
      expect(const MoneyFormat(symbol: 'BDT').format(Money.fromTaka(7000)), 'BDT 7,000');
    });

    test('standard format is South Asian with the taka sign', () {
      expect(MoneyFormat.standard.format(Money.fromTaka(1250000)), '৳12,50,000');
    });
  });
}
