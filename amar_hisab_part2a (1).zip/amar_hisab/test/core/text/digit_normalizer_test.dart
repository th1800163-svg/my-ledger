import 'package:amar_hisab/core/text/digit_normalizer.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('normalizeDigits', () {
    test('converts every Bengali digit', () {
      expect(normalizeDigits('০১২৩৪৫৬৭৮৯'), '0123456789');
    });

    test('leaves Latin digits and other text alone', () {
      expect(normalizeDigits('A৪২ b-7'), 'A42 b-7');
    });
  });

  group('normalizeNumberInput', () {
    test('removes spaces, commas and non-breaking spaces', () {
      expect(normalizeNumberInput(' 1,2 50 '), '1250');
      expect(normalizeNumberInput('1\u00A0250'), '1250');
    });

    test('turns the typographic minus into a normal one', () {
      expect(normalizeNumberInput('\u22125'), '-5');
    });

    test('Bengali digits with decimals', () {
      expect(normalizeNumberInput('১,২৫০.৫০'), '1250.50');
    });
  });
}
