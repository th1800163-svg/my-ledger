import 'package:amar_hisab/core/money/money.dart';
import 'package:amar_hisab/core/money/weight.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Money basics', () {
    test('whole Taka are stored as paisa', () {
      expect(Money.fromTaka(7000).paisa, 700000);
      expect(const Money(5).paisa, 5);
    });

    test('adds, subtracts and negates exactly', () {
      expect(Money.fromTaka(10) + const Money(50), const Money(1050));
      expect(Money.fromTaka(10) - const Money(50), const Money(950));
      expect(-const Money(150), const Money(-150));
    });

    test('ten times ten paisa is exactly one Taka (no floating-point drift)', () {
      final total = Money.sum(List<Money>.filled(10, const Money(10)));
      expect(total, Money.fromTaka(1));
    });

    test('sum of nothing is zero', () {
      expect(Money.sum(const <Money>[]), Money.zero);
    });

    test('comparison and min/max', () {
      expect(Money.fromTaka(2) > Money.fromTaka(1), isTrue);
      expect(Money.fromTaka(1) <= Money.fromTaka(1), isTrue);
      expect(Money.min(const Money(3), const Money(7)), const Money(3));
      expect(Money.max(const Money(3), const Money(7)), const Money(7));
    });

    test('sign helpers', () {
      expect(Money.zero.isZero, isTrue);
      expect(const Money(1).isPositive, isTrue);
      expect(const Money(-1).isNegative, isTrue);
    });

    test('times multiplies by a whole number', () {
      expect(const Money(250).times(4), const Money(1000));
    });
  });

  group('Money.forWeight (rule R1)', () {
    test('20 kg at 350 per kg is 7,000 Taka', () {
      expect(
        Money.forWeight(Weight.fromKg(20), Money.fromTaka(350)),
        Money.fromTaka(7000),
      );
    });

    test('3 broilers at 2 kg each, 220 per kg, is 1,320 Taka', () {
      final estimated = const Weight(2000).times(3);
      expect(Money.forWeight(estimated, Money.fromTaka(220)), Money.fromTaka(1320));
    });

    test('2.5 kg at 220 per kg is exactly 550 Taka', () {
      expect(Money.forWeight(const Weight(2500), Money.fromTaka(220)), Money.fromTaka(550));
    });

    test('rounds half up to the nearest paisa', () {
      // 1 g at 5.00 per kg = 0.5 paisa -> rounds up to 1 paisa.
      expect(Money.forWeight(const Weight(1), const Money(500)), const Money(1));
      // 1 g at 4.99 per kg = 0.499 paisa -> rounds down to 0.
      expect(Money.forWeight(const Weight(1), const Money(499)), Money.zero);
      // 1.234 kg at 333.33 per kg = 411.33422 Taka -> 41133 paisa.
      expect(Money.forWeight(const Weight(1234), const Money(33333)), const Money(41133));
    });

    test('zero weight costs nothing', () {
      expect(Money.forWeight(Weight.zero, Money.fromTaka(350)), Money.zero);
    });

    test('largest allowed values do not overflow', () {
      // 50,000 kg at 10,000 per kg = 50 crore Taka.
      expect(
        Money.forWeight(const Weight(50000000), const Money(1000000)),
        const Money(50000000000),
      );
    });
  });

  group('Money.percentage (half-time deposit)', () {
    test('50 percent of 800 Taka is 400 Taka', () {
      expect(Money.fromTaka(800).percentage(50), Money.fromTaka(400));
    });

    test('0 and 100 percent', () {
      expect(Money.fromTaka(800).percentage(0), Money.zero);
      expect(Money.fromTaka(800).percentage(100), Money.fromTaka(800));
    });

    test('rounds half up', () {
      // 33% of 0.02 Taka = 0.66 paisa -> 1 paisa; 33% of 0.01 = 0.33 -> 0.
      expect(const Money(2).percentage(33), const Money(1));
      expect(const Money(1).percentage(33), Money.zero);
    });
  });

  group('Money.toInputString', () {
    test('whole Taka have no decimals', () {
      expect(Money.fromTaka(7000).toInputString(), '7000');
    });

    test('paisa show two decimals', () {
      expect(const Money(700050).toInputString(), '7000.50');
      expect(const Money(5).toInputString(), '0.05');
      expect(const Money(-150).toInputString(), '-1.50');
    });
  });
}
