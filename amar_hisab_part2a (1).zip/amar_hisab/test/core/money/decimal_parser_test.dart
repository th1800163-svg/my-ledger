import 'package:amar_hisab/core/money/decimal_parser.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  int? scaled(String? input, {int scale = 2}) =>
      DecimalParser.parseScaled(input, scale: scale).scaled;

  DecimalParseError? error(String? input, {int scale = 2}) =>
      DecimalParser.parseScaled(input, scale: scale).error;

  group('parseScaled', () {
    test('whole numbers and decimals', () {
      expect(scaled('12'), 1200);
      expect(scaled('12.5'), 1250);
      expect(scaled('12.50'), 1250);
      expect(scaled('0.05'), 5);
      expect(scaled('007'), 700);
    });

    test('leading or trailing decimal point', () {
      expect(scaled('.5'), 50);
      expect(scaled('12.'), 1200);
    });

    test('trailing zeros beyond the scale are harmless', () {
      expect(scaled('12.500'), 1250);
      expect(scaled('2.250', scale: 3), 2250);
    });

    test('weights use 3 decimals', () {
      expect(scaled('2.5', scale: 3), 2500);
      expect(scaled('0.001', scale: 3), 1);
    });

    test('commas and spaces are ignored', () {
      expect(scaled('1,250.75'), 125075);
      expect(scaled(' 12.5 '), 1250);
      expect(scaled('1\u00A0250'), 125000);
    });

    test('Bengali digits are understood', () {
      expect(scaled('১২.৫'), 1250);
      expect(scaled('২৫০'), 25000);
    });

    test('too many decimals is rejected, not rounded', () {
      expect(error('12.555'), DecimalParseError.tooManyDecimals);
      expect(error('2.5555', scale: 3), DecimalParseError.tooManyDecimals);
    });

    test('negative numbers are reported as negative', () {
      expect(error('-5'), DecimalParseError.negative);
      expect(error('\u22125'), DecimalParseError.negative);
    });

    test('empty and blank input', () {
      expect(error(''), DecimalParseError.empty);
      expect(error('   '), DecimalParseError.empty);
      expect(error(null), DecimalParseError.empty);
    });

    test('garbage is invalid', () {
      expect(error('abc'), DecimalParseError.invalidFormat);
      expect(error('1.2.3'), DecimalParseError.invalidFormat);
      expect(error('1e5'), DecimalParseError.invalidFormat);
      expect(error('.'), DecimalParseError.invalidFormat);
      expect(error('+5'), DecimalParseError.invalidFormat);
      expect(error('12abc'), DecimalParseError.invalidFormat);
    });

    test('absurdly long numbers are rejected before they can overflow', () {
      expect(error('1000000000000'), DecimalParseError.tooLarge);
      expect(scaled('999999999999'), 99999999999900);
    });
  });

  group('parseWhole', () {
    int? whole(String? input) => DecimalParser.parseWhole(input).scaled;
    DecimalParseError? wholeError(String? input) => DecimalParser.parseWhole(input).error;

    test('accepts whole numbers', () {
      expect(whole('10'), 10);
      expect(whole('0'), 0);
      expect(whole('১০'), 10);
      expect(whole('1,000'), 1000);
    });

    test('rejects decimals, negatives and garbage', () {
      expect(wholeError('10.5'), DecimalParseError.invalidFormat);
      expect(wholeError('-1'), DecimalParseError.negative);
      expect(wholeError('x'), DecimalParseError.invalidFormat);
      expect(wholeError(''), DecimalParseError.empty);
    });

    test('too many digits', () {
      expect(wholeError('1000000000000'), DecimalParseError.tooLarge);
    });
  });
}
