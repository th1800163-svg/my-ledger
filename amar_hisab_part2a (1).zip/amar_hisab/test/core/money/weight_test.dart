import 'package:amar_hisab/core/money/weight.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('Weight', () {
    test('kilograms convert to grams', () {
      expect(Weight.fromKg(2).grams, 2000);
    });

    test('adds, subtracts and multiplies exactly', () {
      expect(const Weight(100) + const Weight(200), const Weight(300));
      expect(const Weight(500) - const Weight(200), const Weight(300));
      expect(const Weight(1500).times(4), const Weight(6000));
    });

    test('comparison', () {
      expect(const Weight(2) > const Weight(1), isTrue);
      expect(const Weight(1) <= const Weight(1), isTrue);
      expect(const Weight(1) < const Weight(2), isTrue);
    });

    test('sign helpers', () {
      expect(Weight.zero.isZero, isTrue);
      expect(const Weight(1).isPositive, isTrue);
      expect(const Weight(-1).isNegative, isTrue);
    });
  });

  group('Weight.toKgString', () {
    test('whole kilograms have no decimals', () {
      expect(const Weight(2000).toKgString(), '2');
    });

    test('trailing zeros are removed', () {
      expect(const Weight(2500).toKgString(), '2.5');
      expect(const Weight(2050).toKgString(), '2.05');
    });

    test('keeps grams precision', () {
      expect(const Weight(1234).toKgString(), '1.234');
      expect(const Weight(50).toKgString(), '0.05');
      expect(const Weight(1).toKgString(), '0.001');
    });

    test('zero and negative', () {
      expect(Weight.zero.toKgString(), '0');
      expect(const Weight(-2500).toKgString(), '-2.5');
    });
  });
}
