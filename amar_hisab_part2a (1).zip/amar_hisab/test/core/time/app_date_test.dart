import 'package:amar_hisab/core/time/app_clock.dart';
import 'package:amar_hisab/core/time/date_format.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('storage formats', () {
    test('date and time are zero-padded', () {
      expect(AppDate.toDbDate(DateTime(2026, 10, 7)), '2026-10-07');
      expect(AppDate.toDbDate(DateTime(2026, 1, 5)), '2026-01-05');
      expect(AppDate.toDbTime(DateTime(2026, 10, 7, 5, 3, 9)), '05:03:09');
      expect(AppDate.toDbTime(DateTime(2026, 10, 7, 15, 45, 30)), '15:45:30');
    });

    test('UTC ISO timestamp', () {
      expect(
        AppDate.toUtcIso(DateTime.utc(2026, 10, 7, 9, 45, 30)),
        '2026-10-07T09:45:30.000Z',
      );
    });

    test('parseDbDate accepts real dates', () {
      expect(AppDate.parseDbDate('2026-10-07'), DateTime(2026, 10, 7));
      expect(AppDate.parseDbDate('2028-02-29'), DateTime(2028, 2, 29));
    });

    test('parseDbDate rejects wrong shapes and impossible dates', () {
      expect(() => AppDate.parseDbDate('2026-1-7'), throwsFormatException);
      expect(() => AppDate.parseDbDate('07/10/2026'), throwsFormatException);
      expect(() => AppDate.parseDbDate('2026-02-30'), throwsFormatException);
      expect(() => AppDate.parseDbDate('2027-02-29'), throwsFormatException);
      expect(() => AppDate.parseDbDate('2026-13-01'), throwsFormatException);
      expect(AppDate.isValidDbDate('2026-10-07'), isTrue);
      expect(AppDate.isValidDbDate('2026-02-30'), isFalse);
    });

    test('parseDbDateTime combines date and time', () {
      expect(
        AppDate.parseDbDateTime('2026-10-07', '15:45:30'),
        DateTime(2026, 10, 7, 15, 45, 30),
      );
      expect(() => AppDate.parseDbDateTime('2026-10-07', '25:00:00'), throwsFormatException);
      expect(() => AppDate.parseDbDateTime('2026-10-07', '9:00'), throwsFormatException);
    });
  });

  group('display formats (English)', () {
    test('date', () {
      expect(AppDate.display(DateTime(2026, 10, 7)), '07 Oct 2026');
      expect(AppDate.displayDbDate('2026-01-31'), '31 Jan 2026');
    });

    test('12-hour time', () {
      expect(AppDate.displayTime(DateTime(2026, 10, 7, 15, 45)), '3:45 PM');
      expect(AppDate.displayTime(DateTime(2026, 10, 7, 9, 5)), '9:05 AM');
      expect(AppDate.displayTime(DateTime(2026, 10, 7, 0, 0)), '12:00 AM');
      expect(AppDate.displayTime(DateTime(2026, 10, 7, 12, 0)), '12:00 PM');
      expect(AppDate.displayDbTime('15:45:30'), '3:45 PM');
    });

    test('date and time together, month heading', () {
      expect(
        AppDate.displayDateTime(DateTime(2026, 10, 7, 15, 45)),
        '07 Oct 2026, 3:45 PM',
      );
      expect(AppDate.displayMonth(DateTime(2026, 10, 7)), 'October 2026');
    });
  });

  group('calendar helpers', () {
    test('addDays crosses month and year ends', () {
      expect(AppDate.addDays(DateTime(2026, 10, 31), 1), DateTime(2026, 11, 1));
      expect(AppDate.addDays(DateTime(2026, 12, 31), 1), DateTime(2027, 1, 1));
      expect(AppDate.addDays(DateTime(2026, 3, 1), -1), DateTime(2026, 2, 28));
    });

    test('month boundaries, including leap years', () {
      expect(AppDate.startOfMonth(DateTime(2026, 10, 17)), DateTime(2026, 10, 1));
      expect(AppDate.endOfMonth(DateTime(2026, 10, 17)), DateTime(2026, 10, 31));
      expect(AppDate.endOfMonth(DateTime(2026, 2, 10)), DateTime(2026, 2, 28));
      expect(AppDate.endOfMonth(DateTime(2028, 2, 10)), DateTime(2028, 2, 29));
      expect(AppDate.endOfMonth(DateTime(2026, 12, 1)), DateTime(2026, 12, 31));
    });

    test('week starts on Saturday by default (7 Oct 2026 is a Wednesday)', () {
      expect(DateTime(2026, 10, 7).weekday, DateTime.wednesday);
      expect(AppDate.startOfWeek(DateTime(2026, 10, 7)), DateTime(2026, 10, 3));
      expect(AppDate.startOfWeek(DateTime(2026, 10, 3)), DateTime(2026, 10, 3));
      expect(AppDate.startOfWeek(DateTime(2026, 10, 9)), DateTime(2026, 10, 3));
      expect(AppDate.startOfWeek(DateTime(2026, 10, 10)), DateTime(2026, 10, 10));
    });

    test('week start can be changed', () {
      expect(
        AppDate.startOfWeek(DateTime(2026, 10, 7), weekStartsOn: DateTime.sunday),
        DateTime(2026, 10, 4),
      );
      expect(
        AppDate.startOfWeek(DateTime(2026, 10, 7), weekStartsOn: DateTime.monday),
        DateTime(2026, 10, 5),
      );
    });

    test('dateOnly and isSameDay', () {
      expect(AppDate.dateOnly(DateTime(2026, 10, 7, 15, 45)), DateTime(2026, 10, 7));
      expect(
        AppDate.isSameDay(DateTime(2026, 10, 7, 1), DateTime(2026, 10, 7, 23)),
        isTrue,
      );
      expect(AppDate.isSameDay(DateTime(2026, 10, 7), DateTime(2026, 10, 8)), isFalse);
    });
  });

  group('FixedClock', () {
    test('returns the time it was given and can be moved', () {
      final clock = FixedClock(DateTime(2026, 10, 7, 15, 45, 30));
      expect(clock.now(), DateTime(2026, 10, 7, 15, 45, 30));
      clock.advance(const Duration(hours: 9));
      expect(clock.now(), DateTime(2026, 10, 8, 0, 45, 30));
      clock.set(DateTime(2026, 1, 1));
      expect(clock.now(), DateTime(2026, 1, 1));
    });

    test('today is the date at midnight', () {
      final clock = FixedClock(DateTime(2026, 10, 7, 15, 45, 30));
      expect(clock.today, DateTime(2026, 10, 7));
    });

    test('SystemClock gives a recent time', () {
      final before = DateTime.now().subtract(const Duration(seconds: 1));
      expect(const SystemClock().now().isAfter(before), isTrue);
    });
  });
}
