import 'package:amar_hisab/core/db/app_database.dart';
import 'package:amar_hisab/core/db/row_reader.dart';
import 'package:amar_hisab/core/errors/app_exception.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite/sqflite.dart' show Transaction;

import 'test_db.dart';

void main() {
  late AppDatabase db;

  setUp(() async {
    db = await openTestDb();
  });

  tearDown(() async {
    await db.close();
  });

  Future<int> insertDealerIn(Transaction txn, String name) {
    return txn.insert('dealers', <String, Object?>{
      'name': name,
      'name_key': name.toLowerCase(),
      'created_at': testTimestamp,
      'updated_at': testTimestamp,
    });
  }

  group('write() is all-or-nothing', () {
    test('a failure in the middle undoes everything written before it', () async {
      await expectLater(
        db.write((txn) async {
          final dealerId = await insertDealerIn(txn, 'Ali');
          // The cost does not match weight x rate, so the CHECK rule refuses it.
          await txn.insert(
            'purchases',
            purchaseFields(dealerId, <String, Object?>{'chicken_cost_paisa': 1}),
          );
        }),
        throwsA(isA<BusinessRuleException>()),
      );
      expect(await countRows(db, 'dealers'), 0);
      expect(await countRows(db, 'purchases'), 0);
    });

    test('success keeps everything and returns the action result', () async {
      final dealerId = await db.write((txn) async {
        final id = await insertDealerIn(txn, 'Ali');
        await txn.insert('purchases', purchaseFields(id));
        return id;
      });
      expect(dealerId, greaterThan(0));
      expect(await countRows(db, 'dealers'), 1);
      expect(await countRows(db, 'purchases'), 1);
    });

    test('an ordinary Dart error rolls back too and passes through unchanged', () async {
      await expectLater(
        db.write((txn) async {
          await insertDealerIn(txn, 'Ali');
          throw StateError('boom');
        }),
        throwsA(isA<StateError>()),
      );
      expect(await countRows(db, 'dealers'), 0);
    });
  });

  group('database errors become plain-English app exceptions', () {
    test('receiving more than is due', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      await expectLater(
        db.write((txn) async {
          await txn.insert('customer_payments', <String, Object?>{
            ...receiptFields(700001),
            'bill_id': bill,
            'kind': 'later',
          });
        }),
        throwsA(
          isA<BusinessRuleException>()
              .having((e) => e.code, 'code', 'overpay')
              .having((e) => e.message, 'message', 'That amount is more than what is still due.'),
        ),
      );
    });

    test('the same form saved twice', () async {
      final fields = <String, Object?>{...txnFields(), ...saleFields()};
      await db.write((txn) => txn.insert('retail_sales', fields));
      await expectLater(
        db.write((txn) => txn.insert('retail_sales', <String, Object?>{...fields, 'txn_no': 'X-1'})),
        throwsA(isA<DuplicateSubmissionException>()),
      );
      expect(await countRows(db, 'retail_sales'), 1);
    });

    test('deleting a bill that has payments', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      await insertCustomerPayment(db, bill, 100);
      await expectLater(
        db.write((txn) async {
          await txn.update(
            'customer_transactions',
            <String, Object?>{'deleted_at': testTimestamp},
            where: 'id = ?',
            whereArgs: <Object?>[bill],
          );
        }),
        throwsA(isA<BusinessRuleException>().having((e) => e.code, 'code', 'has_payments')),
      );
    });

    test('a record that points at something missing', () async {
      await expectLater(
        db.write((txn) => txn.insert('purchases', purchaseFields(9999))),
        throwsA(isA<BusinessRuleException>().having((e) => e.code, 'code', 'missing_reference')),
      );
    });
  });

  group('read()', () {
    test('returns query results', () async {
      await insertDealer(db, name: 'Ali');
      final names = await db.read((executor) async {
        final rows = await executor.query('dealers');
        return rows.map((row) => row.stringOf('name')).toList();
      });
      expect(names, <String>['Ali']);
    });
  });
}
