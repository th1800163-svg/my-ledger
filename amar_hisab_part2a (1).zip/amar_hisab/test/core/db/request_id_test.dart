import 'dart:math';

import 'package:amar_hisab/core/db/request_id.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('is 32 lowercase hex characters', () {
    final id = RequestId.generate();
    expect(id.length, 32);
    expect(RegExp(r'^[0-9a-f]{32}$').hasMatch(id), isTrue);
  });

  test('a thousand ids are all different', () {
    final ids = <String>{for (var i = 0; i < 1000; i++) RequestId.generate()};
    expect(ids.length, 1000);
  });

  test('a seeded random source gives a repeatable id', () {
    expect(RequestId.generate(Random(42)), RequestId.generate(Random(42)));
    expect(RequestId.generate(Random(42)), isNot(RequestId.generate(Random(43))));
  });
}
