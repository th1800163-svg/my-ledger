import 'package:amar_hisab/core/db/app_database.dart';
import 'package:amar_hisab/core/db/row_reader.dart';
import 'package:amar_hisab/core/db/sql_filters.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_db.dart';

void main() {
  group('WhereBuilder text', () {
    test('no conditions means "everything"', () {
      final where = WhereBuilder();
      expect(where.clause, '1 = 1');
      expect(where.arguments, isEmpty);
      expect(where.isEmpty, isTrue);
    });

    test('conditions are joined with AND and keep their arguments in order', () {
      final where = WhereBuilder()
          .add('deleted_at IS NULL')
          .dateRange('transaction_date', from: '2026-10-01', to: '2026-10-31')
          .equalsIfSet('chicken_type', 'broiler');
      expect(
        where.clause,
        '(deleted_at IS NULL) AND (transaction_date >= ?) AND (transaction_date <= ?) AND (chicken_type = ?)',
      );
      expect(where.arguments, <Object?>['2026-10-01', '2026-10-31', 'broiler']);
    });

    test('open-ended ranges and unset values add nothing', () {
      final where = WhereBuilder()
          .dateRange('d', from: '2026-10-01')
          .dateRange('d', to: null)
          .equalsIfSet('x', null)
          .searchAny(<String>['name'], '   ')
          .searchAny(<String>['name'], null);
      expect(where.clause, '(d >= ?)');
      expect(where.arguments, <Object?>['2026-10-01']);
    });

    test('search covers every column with the same pattern', () {
      final where = WhereBuilder().searchAny(<String>['name', 'phone'], 'rah');
      expect(where.arguments, <Object?>['%rah%', '%rah%']);
      expect(where.clause.contains('name LIKE ?'), isTrue);
      expect(where.clause.contains('phone LIKE ?'), isTrue);
    });

    test('escapeLike makes % _ and backslash literal', () {
      expect(WhereBuilder.escapeLike('50%'), r'50\%');
      expect(WhereBuilder.escapeLike('a_b'), r'a\_b');
      expect(WhereBuilder.escapeLike(r'a\b'), r'a\\b');
    });
  });

  group('WhereBuilder against a real database', () {
    late AppDatabase db;

    setUp(() async {
      db = await openTestDb();
      for (final name in <String>['Rahim', '100% Fresh', 'a_b', 'axb', "O'Brien", 'Karim']) {
        await insertCustomer(db, name: name);
      }
      await db.raw.update(
        'customers',
        <String, Object?>{'phone': '01712345678'},
        where: 'name = ?',
        whereArgs: <Object?>['Rahim'],
      );
    });

    tearDown(() async {
      await db.close();
    });

    Future<List<String>> search(String query) async {
      final where = WhereBuilder().searchAny(<String>['name', 'phone'], query);
      final rows = await db.raw.query(
        'customers',
        where: where.clause,
        whereArgs: where.arguments,
        orderBy: 'name',
      );
      return rows.map((row) => row.stringOf('name')).toList();
    }

    test('finds partial names, case-insensitively for English letters', () async {
      expect(await search('rah'), <String>['Rahim']);
      expect(await search('RIM'), <String>['Karim', 'Rahim']);
    });

    test('finds by phone number', () async {
      expect(await search('0171234'), <String>['Rahim']);
    });

    test('percent and underscore are searched literally', () async {
      expect(await search('%'), <String>['100% Fresh']);
      expect(await search('a_b'), <String>['a_b']); // must not also match "axb"
    });

    test('a quote in the search text cannot break the query', () async {
      expect(await search("O'B"), <String>["O'Brien"]);
    });

    test('blank search returns everyone', () async {
      expect((await search('')).length, 6);
    });
  });
}
