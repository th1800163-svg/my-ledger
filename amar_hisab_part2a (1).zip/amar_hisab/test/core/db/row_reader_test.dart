import 'package:amar_hisab/core/db/row_reader.dart';
import 'package:amar_hisab/core/money/money.dart';
import 'package:amar_hisab/core/money/weight.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  final row = <String, Object?>{
    'count': 7,
    'name': 'Ali',
    'empty': null,
    'flag_on': 1,
    'flag_off': 0,
    'total_paisa': 700000,
    'weight_g': 2500,
  };

  test('reads ints, strings and flags', () {
    expect(row.intOf('count'), 7);
    expect(row.stringOf('name'), 'Ali');
    expect(row.boolOf('flag_on'), isTrue);
    expect(row.boolOf('flag_off'), isFalse);
  });

  test('reads money and weight', () {
    expect(row.moneyOf('total_paisa'), Money.fromTaka(7000));
    expect(row.weightOf('weight_g'), const Weight(2500));
  });

  test('nullable readers give null for NULL columns', () {
    expect(row.intOrNull('empty'), isNull);
    expect(row.stringOrNull('empty'), isNull);
    expect(row.moneyOrNull('empty'), isNull);
    expect(row.weightOrNull('empty'), isNull);
    expect(row.moneyOrNull('total_paisa'), Money.fromTaka(7000));
    expect(row.weightOrNull('weight_g'), const Weight(2500));
  });

  test('a wrong type fails loudly and names the column', () {
    expect(
      () => row.intOf('name'),
      throwsA(isA<StateError>().having((e) => e.message, 'message', contains('"name"'))),
    );
    expect(() => row.stringOf('count'), throwsStateError);
    expect(() => row.intOf('empty'), throwsStateError);
    expect(() => row.intOf('missing_column'), throwsStateError);
  });
}
