import 'package:amar_hisab/core/db/app_database.dart';
import 'package:amar_hisab/core/db/row_reader.dart';
import 'package:amar_hisab/core/db/seed_data.dart';
import 'package:amar_hisab/core/db/settings_defaults.dart';
import 'package:amar_hisab/core/time/date_format.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_db.dart';

const List<String> _expectedTables = <String>[
  'settings', 'txn_counters', 'audit_log', 'chicken_rates', 'dealers', 'purchases',
  'retail_sales', 'customers', 'customer_transactions', 'customer_payments', 'hotels',
  'hotel_transactions', 'hotel_payments', 'drivers', 'autos', 'auto_daily_status',
  'auto_deposits', 'expense_categories', 'auto_expenses', 'household_expenses',
  'general_expenses',
];

void main() {
  late AppDatabase db;

  setUp(() async {
    db = await openTestDb();
  });

  tearDown(() async {
    await db.close();
  });

  test('schema version is 1', () async {
    expect(AppDatabase.schemaVersion, 1);
    expect(await db.userVersion(), 1);
  });

  test('all 21 tables exist', () async {
    final rows = await db.raw.rawQuery(
      "SELECT name FROM sqlite_master WHERE type = 'table' AND name NOT LIKE 'sqlite_%'",
    );
    final names = rows.map((row) => row.stringOf('name')).toSet();
    expect(names, containsAll(_expectedTables));
    expect(names.length, _expectedTables.length);
  });

  test('the three views exist', () async {
    final rows = await db.raw.rawQuery("SELECT name FROM sqlite_master WHERE type = 'view'");
    final names = rows.map((row) => row.stringOf('name')).toList();
    expect(names, unorderedEquals(<String>['v_customer_bills', 'v_hotel_bills', 'v_auto_days']));
  });

  test('foreign keys are enforced', () async {
    final rows = await db.raw.rawQuery('PRAGMA foreign_keys');
    expect(rows.first.values.first, 1);
    // A customer bill for a customer that does not exist must be refused.
    await expectDbError(
      db.raw.insert('customer_transactions', <String, Object?>{
        ...txnFields(),
        'customer_id': 9999,
        ...saleFields(),
      }),
      'FOREIGN KEY',
    );
  });

  test('default settings are seeded once', () async {
    expect(await countRows(db, 'settings'), SettingDefaults.values.length);
    final rows = await db.raw.query('settings', where: 'key = ?', whereArgs: <Object?>['app_name']);
    expect(rows.single.stringOf('value'), 'My Ledger');
    expect(rows.single.stringOf('updated_at'), AppDate.toUtcIso(testNow));

    Future<String> setting(String key) async {
      final result = await db.raw.query('settings', where: 'key = ?', whereArgs: <Object?>[key]);
      return result.single.stringOf('value');
    }

    expect(await setting(SettingKeys.dbAppId), 'amar_hisab');
    expect(await setting(SettingKeys.currencySymbol), '৳');
    expect(await setting(SettingKeys.halfTimePercent), '50');
    expect(await setting(SettingKeys.firstRunCompleted), '0');
  });

  test('built-in expense categories are seeded: 18 auto, 14 household, 1 general', () async {
    expect(await countRows(db, 'expense_categories', where: "scope = 'auto'"), 18);
    expect(await countRows(db, 'expense_categories', where: "scope = 'household'"), 14);
    expect(await countRows(db, 'expense_categories', where: "scope = 'general'"), 1);
    expect(SeedData.autoCategories.length, 18);
    expect(SeedData.householdCategories.length, 14);
    expect(await countRows(db, 'expense_categories', where: 'is_builtin = 1'), 33);
  });

  test('no business data is pre-filled (no fake data)', () async {
    const empty = <String>[
      'chicken_rates', 'dealers', 'purchases', 'retail_sales', 'customers',
      'customer_transactions', 'customer_payments', 'hotels', 'hotel_transactions',
      'hotel_payments', 'drivers', 'autos', 'auto_daily_status', 'auto_deposits',
      'auto_expenses', 'household_expenses', 'general_expenses', 'audit_log', 'txn_counters',
    ];
    for (final table in empty) {
      expect(await countRows(db, table), 0, reason: table);
    }
  });

  test('a category name is unique within its scope but may repeat across scopes', () async {
    expect(await countRows(db, 'expense_categories', where: "name = 'Other'"), 3);
    await expectDbError(
      db.raw.insert('expense_categories', <String, Object?>{
        'scope': 'auto',
        'name': 'Battery',
        'created_at': testTimestamp,
      }),
      'UNIQUE',
    );
    // A custom category can be added.
    final id = await db.raw.insert('expense_categories', <String, Object?>{
      'scope': 'household',
      'name': 'Pet food',
      'created_at': testTimestamp,
    });
    expect(id, greaterThan(0));
  });
}
