import 'package:amar_hisab/core/db/app_database.dart';
import 'package:amar_hisab/core/db/txn_numbers.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_db.dart';

void main() {
  late AppDatabase db;
  final oct7 = DateTime(2026, 10, 7);

  setUp(() async {
    db = await openTestDb();
  });

  tearDown(() async {
    await db.close();
  });

  Future<String> next(TxnPrefix prefix, DateTime date) =>
      db.write((txn) => TxnNumbers.next(txn, prefix, date));

  test('numbers run 001, 002, 003 for the same prefix and day', () async {
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-001');
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-002');
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-003');
  });

  test('each prefix has its own counter', () async {
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-001');
    expect(await next(TxnPrefix.retailSale, oct7), 'RET-20261007-001');
    expect(await next(TxnPrefix.customerReceipt, oct7), 'RCC-20261007-001');
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-002');
  });

  test('each day starts again from 001, and back-dated entries use their own date', () async {
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-001');
    expect(await next(TxnPrefix.purchase, DateTime(2026, 10, 8)), 'PUR-20261008-001');
    expect(await next(TxnPrefix.purchase, DateTime(2026, 10, 1)), 'PUR-20261001-001');
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-002');
  });

  test('single-digit months and days are zero padded', () async {
    expect(await next(TxnPrefix.householdExpense, DateTime(2026, 1, 5)), 'HEX-20260105-001');
  });

  test('every prefix code', () {
    expect(
      TxnPrefix.values.map((prefix) => prefix.code).toList(),
      <String>['PUR', 'RET', 'CUS', 'HTL', 'RCC', 'RCH', 'AST', 'DEP', 'AEX', 'HEX', 'GEX'],
    );
  });

  test('a failed save does not use up a number', () async {
    await expectLater(
      db.write((txn) async {
        await TxnNumbers.next(txn, TxnPrefix.purchase, oct7);
        throw StateError('save failed after reserving a number');
      }),
      throwsA(isA<StateError>()),
    );
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-001');
  });

  test('the counter keeps growing past 999', () async {
    await db.raw.insert('txn_counters', <String, Object?>{
      'counter_key': 'PUR-20261007',
      'last_value': 999,
    });
    expect(await next(TxnPrefix.purchase, oct7), 'PUR-20261007-1000');
  });

  test('numbers from one transaction are all different', () async {
    final numbers = await db.write((txn) async {
      final list = <String>[];
      for (var i = 0; i < 25; i++) {
        list.add(await TxnNumbers.next(txn, TxnPrefix.customerBill, oct7));
      }
      return list;
    });
    expect(numbers.toSet().length, 25);
    expect(numbers.first, 'CUS-20261007-001');
    expect(numbers.last, 'CUS-20261007-025');
  });
}
