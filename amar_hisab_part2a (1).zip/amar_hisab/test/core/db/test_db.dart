import 'package:amar_hisab/core/db/app_database.dart';
import 'package:amar_hisab/core/db/row_reader.dart';
import 'package:amar_hisab/core/time/app_clock.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

/// Every database test runs at this moment: Wednesday 7 Oct 2026, 15:45:30.
final DateTime testNow = DateTime(2026, 10, 7, 15, 45, 30);

/// A fixed text timestamp for columns that tests never compare.
const String testTimestamp = '2026-10-07T09:45:30.000Z';

/// Opens a fresh, empty in-memory database with the real schema.
Future<AppDatabase> openTestDb({FixedClock? clock}) {
  sqfliteFfiInit();
  return AppDatabase.open(
    path: inMemoryDatabasePath,
    clock: clock ?? FixedClock(testNow),
    factory: databaseFactoryFfi,
  );
}

int _sequence = 0;

int _next() => ++_sequence;

/// The columns every transaction row needs, with unique txn_no / request_id.
Map<String, Object?> txnFields({String date = '2026-10-07', String time = '15:45:30'}) {
  final n = _next();
  return <String, Object?>{
    'txn_no': 'T-$n',
    'request_id': 'R-$n',
    'transaction_date': date,
    'transaction_time': time,
    'created_at': testTimestamp,
    'updated_at': testTimestamp,
  };
}

/// The columns every payment / deposit row needs, with unique numbers.
Map<String, Object?> receiptFields(int amountPaisa, {String date = '2026-10-07'}) {
  final n = _next();
  return <String, Object?>{
    'receipt_no': 'RC-$n',
    'request_id': 'RQ-$n',
    'amount_paisa': amountPaisa,
    'transaction_date': date,
    'transaction_time': '16:00:00',
    'created_at': testTimestamp,
    'updated_at': testTimestamp,
  };
}

/// A valid weight-based sale: 20 kg at 350 per kg = 7,000 Taka (700000 paisa).
Map<String, Object?> saleFields([Map<String, Object?> overrides = const <String, Object?>{}]) {
  return <String, Object?>{
    'chicken_type': 'broiler',
    'sale_mode': 'weight',
    'pieces': 0,
    'actual_weight_g': 20000,
    'estimated_weight_g': null,
    'weight_source': 'actual',
    'avg_piece_weight_g_used': null,
    'rate_per_kg_paisa': 35000,
    'total_paisa': 700000,
    ...overrides,
  };
}

/// A valid purchase: 20 kg at 220 per kg + 50 transport = 4,450 Taka.
Map<String, Object?> purchaseFields(
  int dealerId, [
  Map<String, Object?> overrides = const <String, Object?>{},
]) {
  return <String, Object?>{
    ...txnFields(),
    'dealer_id': dealerId,
    'chicken_type': 'broiler',
    'pieces': 10,
    'weight_g': 20000,
    'rate_per_kg_paisa': 22000,
    'chicken_cost_paisa': 440000,
    'transport_paisa': 5000,
    'other_paisa': 0,
    'grand_total_paisa': 445000,
    ...overrides,
  };
}

Future<int> insertDealer(AppDatabase db, {String name = 'Ali'}) {
  return db.raw.insert('dealers', <String, Object?>{
    'name': name,
    'name_key': name.toLowerCase(),
    'created_at': testTimestamp,
    'updated_at': testTimestamp,
  });
}

Future<int> insertCustomer(AppDatabase db, {String name = 'Rahim'}) {
  return db.raw.insert('customers', <String, Object?>{
    'name': name,
    'created_at': testTimestamp,
    'updated_at': testTimestamp,
  });
}

Future<int> insertHotel(AppDatabase db, {String name = 'Grand Hotel'}) {
  return db.raw.insert('hotels', <String, Object?>{
    'name': name,
    'created_at': testTimestamp,
    'updated_at': testTimestamp,
  });
}

/// A customer bill of 7,000 Taka unless [sale] overrides say otherwise.
Future<int> insertCustomerBill(
  AppDatabase db,
  int customerId, [
  Map<String, Object?> sale = const <String, Object?>{},
]) {
  return db.raw.insert('customer_transactions', <String, Object?>{
    ...txnFields(),
    'customer_id': customerId,
    ...saleFields(sale),
  });
}

Future<int> insertHotelBill(AppDatabase db, int hotelId) {
  return db.raw.insert('hotel_transactions', <String, Object?>{
    ...txnFields(),
    'hotel_id': hotelId,
    ...saleFields(),
  });
}

Future<int> insertCustomerPayment(
  AppDatabase db,
  int billId,
  int amountPaisa, {
  String kind = 'later',
}) {
  return db.raw.insert('customer_payments', <String, Object?>{
    ...receiptFields(amountPaisa),
    'bill_id': billId,
    'kind': kind,
  });
}

Future<int> insertHotelPayment(AppDatabase db, int billId, int amountPaisa) {
  return db.raw.insert('hotel_payments', <String, Object?>{
    ...receiptFields(amountPaisa),
    'bill_id': billId,
    'kind': 'later',
  });
}

Future<int> insertDriver(AppDatabase db, {String name = 'Karim'}) {
  return db.raw.insert('drivers', <String, Object?>{
    'name': name,
    'created_at': testTimestamp,
    'updated_at': testTimestamp,
  });
}

Future<int> insertAuto(AppDatabase db, int driverId, {int standardPaisa = 80000}) {
  return db.raw.insert('autos', <String, Object?>{
    'name': 'Auto-1',
    'driver_id': driverId,
    'standard_deposit_paisa': standardPaisa,
    'start_date': '2026-01-01',
    'created_at': testTimestamp,
    'updated_at': testTimestamp,
  });
}

Future<int> insertAutoStatus(
  AppDatabase db,
  int autoId,
  int driverId, {
  String date = '2026-10-07',
  String status = 'full',
  int expectedPaisa = 80000,
  String source = 'standard',
  int? halfPercent,
}) {
  return db.raw.insert('auto_daily_status', <String, Object?>{
    ...txnFields(date: date),
    'auto_id': autoId,
    'driver_id': driverId,
    'status': status,
    'standard_deposit_paisa': 80000,
    'expected_deposit_paisa': expectedPaisa,
    'expected_source': source,
    'half_percent_used': halfPercent,
  });
}

Future<int> insertAutoDeposit(
  AppDatabase db, {
  required int autoId,
  required int driverId,
  required int statusId,
  required int amountPaisa,
}) {
  return db.raw.insert('auto_deposits', <String, Object?>{
    ...receiptFields(amountPaisa),
    'auto_id': autoId,
    'driver_id': driverId,
    'status_id': statusId,
  });
}

/// Number of rows in [table].
Future<int> countRows(AppDatabase db, String table, {String where = '1 = 1'}) async {
  final rows = await db.raw.rawQuery('SELECT COUNT(*) AS c FROM $table WHERE $where');
  return rows.first.intOf('c');
}

/// `paid_paisa` and `due_paisa` of a bill from the given view.
Future<(int, int)> paidAndDue(AppDatabase db, String view, int id) async {
  final rows = await db.raw.rawQuery(
    'SELECT paid_paisa, due_paisa FROM $view WHERE id = ?',
    <Object?>[id],
  );
  return (rows.first.intOf('paid_paisa'), rows.first.intOf('due_paisa'));
}

/// Passes when [future] fails with an error whose text contains [fragment].
Future<void> expectDbError(Future<Object?> future, String fragment) {
  return expectLater(
    future,
    throwsA(
      predicate<Object>(
        (error) => error.toString().contains(fragment),
        'an error containing "$fragment"',
      ),
    ),
  );
}
