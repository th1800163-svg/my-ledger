import 'dart:io';

import 'package:amar_hisab/core/db/app_database.dart';
import 'package:amar_hisab/core/db/row_reader.dart';
import 'package:amar_hisab/core/db/settings_defaults.dart';
import 'package:amar_hisab/core/time/app_clock.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite_common_ffi/sqflite_ffi.dart';

import 'test_db.dart';

/// "Persistence after app restart": data written to a real database file must
/// still be there after the file is closed and opened again.
void main() {
  late Directory directory;
  late String path;

  setUpAll(sqfliteFfiInit);

  setUp(() {
    directory = Directory.systemTemp.createTempSync('amar_hisab_persistence_');
    path = p.join(directory.path, 'ledger.db');
  });

  tearDown(() {
    if (directory.existsSync()) directory.deleteSync(recursive: true);
  });

  Future<AppDatabase> open() => AppDatabase.open(
        path: path,
        clock: FixedClock(testNow),
        factory: databaseFactoryFfi,
      );

  test('data survives closing and reopening the database file', () async {
    var db = await open();
    final dealer = await insertDealer(db, name: 'Ali');
    await db.raw.insert('purchases', purchaseFields(dealer));
    final customer = await insertCustomer(db, name: 'Rahim');
    final bill = await insertCustomerBill(db, customer);
    await insertCustomerPayment(db, bill, 300000);
    await db.close();

    db = await open();
    expect(await countRows(db, 'dealers'), 1);
    expect(await countRows(db, 'purchases'), 1);
    expect(await countRows(db, 'customers'), 1);
    expect(await paidAndDue(db, 'v_customer_bills', bill), (300000, 400000));
    final purchase = (await db.raw.query('purchases')).single;
    expect(purchase.intOf('grand_total_paisa'), 445000);
    await db.close();
  });

  test('reopening does not repeat the first-time setup', () async {
    var db = await open();
    await db.raw.update(
      'settings',
      <String, Object?>{'value': 'Chicken Corner'},
      where: 'key = ?',
      whereArgs: <Object?>[SettingKeys.appName],
    );
    await db.close();

    db = await open();
    // Settings were not re-seeded or overwritten, and categories not duplicated.
    expect(await countRows(db, 'settings'), SettingDefaults.values.length);
    final name = await db.raw.query(
      'settings',
      where: 'key = ?',
      whereArgs: <Object?>[SettingKeys.appName],
    );
    expect(name.single.stringOf('value'), 'Chicken Corner');
    expect(await countRows(db, 'expense_categories'), 33);
    expect(await db.userVersion(), AppDatabase.schemaVersion);
    await db.close();
  });

  test('the database file is created on disk', () async {
    final db = await open();
    await db.close();
    expect(File(path).existsSync(), isTrue);
    expect(File(path).lengthSync(), greaterThan(0));
  });
}
