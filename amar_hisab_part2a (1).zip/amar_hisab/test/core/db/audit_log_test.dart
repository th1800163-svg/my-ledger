import 'dart:convert';

import 'package:amar_hisab/core/db/app_database.dart';
import 'package:amar_hisab/core/db/audit_log.dart';
import 'package:amar_hisab/core/db/row_reader.dart';
import 'package:amar_hisab/core/time/date_format.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_db.dart';

void main() {
  late AppDatabase db;

  setUp(() async {
    db = await openTestDb();
  });

  tearDown(() async {
    await db.close();
  });

  test('records create, update and delete in order with old and new values', () async {
    await db.write((txn) async {
      await AuditLog.record(
        txn,
        table: 'purchases',
        recordId: 7,
        action: AuditAction.create,
        now: testNow,
        newValues: <String, Object?>{'weight_g': 20000},
      );
      await AuditLog.record(
        txn,
        table: 'purchases',
        recordId: 7,
        action: AuditAction.update,
        now: testNow,
        oldValues: <String, Object?>{'weight_g': 20000},
        newValues: <String, Object?>{'weight_g': 21000},
      );
      await AuditLog.record(
        txn,
        table: 'purchases',
        recordId: 7,
        action: AuditAction.delete,
        now: testNow,
        oldValues: <String, Object?>{'weight_g': 21000},
      );
    });

    final history = await AuditLog.historyOf(db.raw, table: 'purchases', recordId: 7);
    expect(history.map((row) => row.stringOf('action')).toList(), <String>['create', 'update', 'delete']);

    expect(history[0].stringOrNull('old_json'), isNull);
    expect(jsonDecode(history[0].stringOf('new_json')), <String, Object?>{'weight_g': 20000});
    expect(jsonDecode(history[1].stringOf('old_json')), <String, Object?>{'weight_g': 20000});
    expect(jsonDecode(history[1].stringOf('new_json')), <String, Object?>{'weight_g': 21000});
    expect(history[2].stringOrNull('new_json'), isNull);
    expect(history[0].stringOf('created_at'), AppDate.toUtcIso(testNow));
  });

  test('history is kept per record and per table', () async {
    await db.write((txn) async {
      await AuditLog.record(txn, table: 'purchases', recordId: 1, action: AuditAction.create, now: testNow);
      await AuditLog.record(txn, table: 'purchases', recordId: 2, action: AuditAction.create, now: testNow);
      await AuditLog.record(txn, table: 'retail_sales', recordId: 1, action: AuditAction.create, now: testNow);
    });
    expect((await AuditLog.historyOf(db.raw, table: 'purchases', recordId: 1)).length, 1);
    expect((await AuditLog.historyOf(db.raw, table: 'purchases', recordId: 2)).length, 1);
    expect((await AuditLog.historyOf(db.raw, table: 'retail_sales', recordId: 1)).length, 1);
    expect((await AuditLog.historyOf(db.raw, table: 'retail_sales', recordId: 2)).length, 0);
  });

  test('an audit entry is rolled back together with a failed change', () async {
    await expectLater(
      db.write((txn) async {
        await AuditLog.record(txn, table: 'purchases', recordId: 1, action: AuditAction.create, now: testNow);
        throw StateError('change failed');
      }),
      throwsA(isA<StateError>()),
    );
    expect(await countRows(db, 'audit_log'), 0);
  });

  test('only create, update and delete are accepted by the database', () async {
    await expectDbError(
      db.raw.insert('audit_log', <String, Object?>{
        'table_name': 'purchases',
        'record_id': 1,
        'action': 'purge',
        'created_at': testTimestamp,
      }),
      'CHECK',
    );
  });
}
