import 'package:amar_hisab/core/db/app_database.dart';
import 'package:flutter_test/flutter_test.dart';

import 'test_db.dart';

/// These tests prove the database itself refuses inconsistent financial data,
/// even if application code had a bug.
void main() {
  late AppDatabase db;

  setUp(() async {
    db = await openTestDb();
  });

  tearDown(() async {
    await db.close();
  });

  group('purchases (rule R2)', () {
    test('a correct purchase is accepted: 20 kg x 220 + 50 transport = 4,450 Taka', () async {
      final dealer = await insertDealer(db);
      final id = await db.raw.insert('purchases', purchaseFields(dealer));
      expect(id, greaterThan(0));
    });

    test('chicken cost must equal weight x rate', () async {
      final dealer = await insertDealer(db);
      await expectDbError(
        db.raw.insert(
          'purchases',
          purchaseFields(dealer, <String, Object?>{
            'chicken_cost_paisa': 440001,
            'grand_total_paisa': 445001,
          }),
        ),
        'CHECK',
      );
    });

    test('grand total must equal cost + transport + other', () async {
      final dealer = await insertDealer(db);
      await expectDbError(
        db.raw.insert(
          'purchases',
          purchaseFields(dealer, <String, Object?>{'grand_total_paisa': 999999}),
        ),
        'CHECK',
      );
    });

    test('cost is rounded half up exactly like Money.forWeight', () async {
      final dealer = await insertDealer(db);
      // 1.234 kg at 333.33 per kg = 41133 paisa (see money_test.dart).
      final id = await db.raw.insert(
        'purchases',
        purchaseFields(dealer, <String, Object?>{
          'weight_g': 1234,
          'rate_per_kg_paisa': 33333,
          'chicken_cost_paisa': 41133,
          'transport_paisa': 0,
          'grand_total_paisa': 41133,
        }),
      );
      expect(id, greaterThan(0));
    });

    test('zero weight, negative rate and a missing dealer are refused', () async {
      final dealer = await insertDealer(db);
      await expectDbError(
        db.raw.insert('purchases', purchaseFields(dealer, <String, Object?>{'weight_g': 0})),
        'CHECK',
      );
      await expectDbError(
        db.raw.insert(
          'purchases',
          purchaseFields(dealer, <String, Object?>{'rate_per_kg_paisa': -1}),
        ),
        'CHECK',
      );
      await expectDbError(db.raw.insert('purchases', purchaseFields(9999)), 'FOREIGN KEY');
    });

    test('only broiler and sonali exist', () async {
      final dealer = await insertDealer(db);
      await expectDbError(
        db.raw.insert('purchases', purchaseFields(dealer, <String, Object?>{'chicken_type': 'duck'})),
        'CHECK',
      );
    });
  });

  group('dates and times', () {
    test('only YYYY-MM-DD and HH:MM:SS are stored', () async {
      final dealer = await insertDealer(db);
      await expectDbError(
        db.raw.insert(
          'purchases',
          <String, Object?>{...purchaseFields(dealer), 'transaction_date': '2026-1-7'},
        ),
        'CHECK',
      );
      await expectDbError(
        db.raw.insert(
          'purchases',
          <String, Object?>{...purchaseFields(dealer), 'transaction_time': '9:00'},
        ),
        'CHECK',
      );
    });
  });

  group('sales (rules R4, shared by retail, customer and hotel)', () {
    test('by weight: 20 kg x 350 = 7,000 Taka', () async {
      final id = await db.raw.insert('retail_sales', <String, Object?>{...txnFields(), ...saleFields()});
      expect(id, greaterThan(0));
    });

    test('by pieces with estimated weight: 3 x 2 kg at 220 = 1,320 Taka', () async {
      final id = await db.raw.insert('retail_sales', <String, Object?>{
        ...txnFields(),
        ...saleFields(<String, Object?>{
          'sale_mode': 'piece',
          'pieces': 3,
          'actual_weight_g': null,
          'estimated_weight_g': 6000,
          'weight_source': 'estimated',
          'avg_piece_weight_g_used': 2000,
          'rate_per_kg_paisa': 22000,
          'total_paisa': 132000,
        }),
      });
      expect(id, greaterThan(0));
    });

    test('by pieces with an actual weight typed', () async {
      final id = await db.raw.insert('retail_sales', <String, Object?>{
        ...txnFields(),
        ...saleFields(<String, Object?>{
          'sale_mode': 'piece',
          'pieces': 3,
          'actual_weight_g': 5500,
          'rate_per_kg_paisa': 22000,
          'total_paisa': 121000,
        }),
      });
      expect(id, greaterThan(0));
    });

    test('by amount: no weight and no rate needed', () async {
      final id = await db.raw.insert('retail_sales', <String, Object?>{
        ...txnFields(),
        ...saleFields(<String, Object?>{
          'sale_mode': 'amount',
          'actual_weight_g': null,
          'weight_source': 'none',
          'rate_per_kg_paisa': null,
          'total_paisa': 50000,
        }),
      });
      expect(id, greaterThan(0));
    });

    final invalid = <String, Map<String, Object?>>{
      'total does not match weight x rate': <String, Object?>{'total_paisa': 700001},
      'weight mode but weight is only estimated': <String, Object?>{
        'actual_weight_g': null,
        'estimated_weight_g': 20000,
        'weight_source': 'estimated',
        'avg_piece_weight_g_used': 2000,
        'pieces': 10,
      },
      'estimated weight without the average that produced it': <String, Object?>{
        'sale_mode': 'piece',
        'pieces': 3,
        'actual_weight_g': null,
        'estimated_weight_g': 6000,
        'weight_source': 'estimated',
        'avg_piece_weight_g_used': null,
        'rate_per_kg_paisa': 22000,
        'total_paisa': 132000,
      },
      'estimated weight is not pieces x average': <String, Object?>{
        'sale_mode': 'piece',
        'pieces': 3,
        'actual_weight_g': null,
        'estimated_weight_g': 6001,
        'weight_source': 'estimated',
        'avg_piece_weight_g_used': 2000,
        'rate_per_kg_paisa': 22000,
        'total_paisa': 132022,
      },
      'piece mode with zero pieces': <String, Object?>{'sale_mode': 'piece', 'pieces': 0},
      'source says actual but no weight': <String, Object?>{'actual_weight_g': null},
      'weight present but source says none': <String, Object?>{'weight_source': 'none'},
      'piece mode without any weight': <String, Object?>{
        'sale_mode': 'piece',
        'pieces': 2,
        'actual_weight_g': null,
        'weight_source': 'none',
      },
      'amount mode with an estimated weight': <String, Object?>{
        'sale_mode': 'amount',
        'actual_weight_g': null,
        'estimated_weight_g': 2000,
        'weight_source': 'estimated',
        'avg_piece_weight_g_used': 2000,
        'pieces': 1,
      },
      'weight mode without a rate': <String, Object?>{'rate_per_kg_paisa': null},
      'zero total': <String, Object?>{
        'sale_mode': 'amount',
        'actual_weight_g': null,
        'weight_source': 'none',
        'rate_per_kg_paisa': null,
        'total_paisa': 0,
      },
      'negative pieces': <String, Object?>{'pieces': -1},
      'zero actual weight': <String, Object?>{'actual_weight_g': 0},
    };

    for (final entry in invalid.entries) {
      test('refuses: ${entry.key}', () async {
        await expectDbError(
          db.raw.insert('retail_sales', <String, Object?>{
            ...txnFields(),
            ...saleFields(entry.value),
          }),
          'CHECK',
        );
      });
    }
  });

  group('duplicate protection (rule R14)', () {
    test('the same request_id cannot create a second row', () async {
      final fields = <String, Object?>{...txnFields(), ...saleFields()};
      await db.raw.insert('retail_sales', fields);
      await expectDbError(
        db.raw.insert('retail_sales', <String, Object?>{...fields, 'txn_no': 'DIFFERENT'}),
        'request_id',
      );
    });

    test('the same transaction number cannot be used twice', () async {
      final fields = <String, Object?>{...txnFields(), ...saleFields()};
      await db.raw.insert('retail_sales', fields);
      await expectDbError(
        db.raw.insert('retail_sales', <String, Object?>{...fields, 'request_id': 'DIFFERENT'}),
        'txn_no',
      );
    });
  });

  group('customer ledger (rule R6)', () {
    test('an unpaid bill: paid 0, due = total', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      expect(await paidAndDue(db, 'v_customer_bills', bill), (0, 700000));
    });

    test('partial then full payment', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      await insertCustomerPayment(db, bill, 300000, kind: 'at_sale');
      expect(await paidAndDue(db, 'v_customer_bills', bill), (300000, 400000));
      await insertCustomerPayment(db, bill, 400000);
      expect(await paidAndDue(db, 'v_customer_bills', bill), (700000, 0));
    });

    test('paying more than is due is blocked by the database', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      await insertCustomerPayment(db, bill, 300000);
      await expectDbError(insertCustomerPayment(db, bill, 400001), 'OVERPAY');
      await insertCustomerPayment(db, bill, 400000);
      await expectDbError(insertCustomerPayment(db, bill, 1), 'OVERPAY');
    });

    test('zero and negative payments are refused', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      await expectDbError(insertCustomerPayment(db, bill, 0), 'CHECK');
      await expectDbError(insertCustomerPayment(db, bill, -5), 'CHECK');
    });

    test('a bill total cannot be lowered below what is already paid', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      await insertCustomerPayment(db, bill, 300000);
      await expectDbError(
        db.raw.update(
          'customer_transactions',
          <String, Object?>{'total_paisa': 200000, 'rate_per_kg_paisa': 10000},
          where: 'id = ?',
          whereArgs: <Object?>[bill],
        ),
        'BELOW_PAID',
      );
    });

    test('a bill with payments cannot be deleted until they are cancelled', () async {
      final customer = await insertCustomer(db);
      final bill = await insertCustomerBill(db, customer);
      await insertCustomerPayment(db, bill, 100000);

      Future<int> softDeleteBill() => db.raw.update(
            'customer_transactions',
            <String, Object?>{'deleted_at': testTimestamp},
            where: 'id = ?',
            whereArgs: <Object?>[bill],
          );

      await expectDbError(softDeleteBill(), 'HAS_PAYMENTS');

      // Cancel the payment (soft delete); its money no longer counts.
      await db.raw.update(
        'customer_payments',
        <String, Object?>{'deleted_at': testTimestamp},
        where: 'bill_id = ?',
        whereArgs: <Object?>[bill],
      );
      expect(await paidAndDue(db, 'v_customer_bills', bill), (0, 700000));

      expect(await softDeleteBill(), 1);
      expect(await countRows(db, 'v_customer_bills', where: 'id = $bill'), 0);
    });

    test('one receipt can cover several bills but not the same bill twice', () async {
      final customer = await insertCustomer(db);
      final billA = await insertCustomerBill(db, customer);
      final billB = await insertCustomerBill(db, customer);
      final shared = <String, Object?>{
        'receipt_no': 'RCC-20261007-001',
        'transaction_date': '2026-10-07',
        'transaction_time': '16:00:00',
        'created_at': testTimestamp,
        'updated_at': testTimestamp,
        'kind': 'later',
        'amount_paisa': 100,
      };
      await db.raw.insert('customer_payments', <String, Object?>{
        ...shared, 'request_id': 'REQ-1', 'bill_id': billA,
      });
      await db.raw.insert('customer_payments', <String, Object?>{
        ...shared, 'request_id': 'REQ-1', 'bill_id': billB,
      });
      await expectDbError(
        db.raw.insert('customer_payments', <String, Object?>{
          ...shared, 'request_id': 'REQ-2', 'bill_id': billA,
        }),
        'UNIQUE',
      );
    });
  });

  group('hotel ledger mirrors the customer ledger', () {
    test('partial payment, overpay blocked, delete blocked', () async {
      final hotel = await insertHotel(db);
      final bill = await insertHotelBill(db, hotel);
      await insertHotelPayment(db, bill, 200000);
      expect(await paidAndDue(db, 'v_hotel_bills', bill), (200000, 500000));
      await expectDbError(insertHotelPayment(db, bill, 500001), 'OVERPAY');
      await expectDbError(
        db.raw.update(
          'hotel_transactions',
          <String, Object?>{'deleted_at': testTimestamp},
          where: 'id = ?',
          whereArgs: <Object?>[bill],
        ),
        'HAS_PAYMENTS',
      );
    });
  });

  group('autos (rules R7)', () {
    test('one status per auto per day', () async {
      final driver = await insertDriver(db);
      final auto = await insertAuto(db, driver);
      await insertAutoStatus(db, auto, driver);
      await expectDbError(insertAutoStatus(db, auto, driver), 'UNIQUE');
      // A different day is fine.
      await insertAutoStatus(db, auto, driver, date: '2026-10-08');
    });

    test('sick day with zero expected and broken day with a manual amount', () async {
      final driver = await insertDriver(db);
      final auto = await insertAuto(db, driver);
      await insertAutoStatus(
        db, auto, driver,
        date: '2026-10-06', status: 'sick', expectedPaisa: 0, source: 'zero',
      );
      await insertAutoStatus(
        db, auto, driver,
        date: '2026-10-05', status: 'broken', expectedPaisa: 25000, source: 'manual',
      );
    });

    test('allowed statuses only, and no negative expected deposit', () async {
      final driver = await insertDriver(db);
      final auto = await insertAuto(db, driver);
      await expectDbError(insertAutoStatus(db, auto, driver, status: 'holiday'), 'CHECK');
      await expectDbError(insertAutoStatus(db, auto, driver, expectedPaisa: -1), 'CHECK');
    });

    test('half time: expected 400 of 800, received 300, due 100', () async {
      final driver = await insertDriver(db);
      final auto = await insertAuto(db, driver);
      final status = await insertAutoStatus(
        db, auto, driver,
        status: 'half', expectedPaisa: 40000, source: 'half_percent', halfPercent: 50,
      );
      await insertAutoDeposit(
        db, autoId: auto, driverId: driver, statusId: status, amountPaisa: 30000,
      );
      final rows = await db.raw.rawQuery(
        'SELECT received_paisa, due_paisa FROM v_auto_days WHERE id = ?',
        <Object?>[status],
      );
      expect(rows.first['received_paisa'], 30000);
      expect(rows.first['due_paisa'], 10000);
    });

    test('deposits cannot exceed the expected amount', () async {
      final driver = await insertDriver(db);
      final auto = await insertAuto(db, driver);
      final status = await insertAutoStatus(db, auto, driver, expectedPaisa: 40000);
      await insertAutoDeposit(
        db, autoId: auto, driverId: driver, statusId: status, amountPaisa: 40000,
      );
      await expectDbError(
        insertAutoDeposit(db, autoId: auto, driverId: driver, statusId: status, amountPaisa: 1),
        'OVERPAY',
      );
    });

    test('expected deposit cannot be lowered below what was received', () async {
      final driver = await insertDriver(db);
      final auto = await insertAuto(db, driver);
      final status = await insertAutoStatus(db, auto, driver, expectedPaisa: 40000);
      await insertAutoDeposit(
        db, autoId: auto, driverId: driver, statusId: status, amountPaisa: 30000,
      );
      await expectDbError(
        db.raw.update(
          'auto_daily_status',
          <String, Object?>{'expected_deposit_paisa': 29999},
          where: 'id = ?',
          whereArgs: <Object?>[status],
        ),
        'BELOW_PAID',
      );
    });

    test('a status with deposits cannot be deleted, and a day can be recreated after delete', () async {
      final driver = await insertDriver(db);
      final auto = await insertAuto(db, driver);
      final status = await insertAutoStatus(db, auto, driver, expectedPaisa: 40000);
      final deposit = await insertAutoDeposit(
        db, autoId: auto, driverId: driver, statusId: status, amountPaisa: 10000,
      );

      Future<int> softDeleteStatus() => db.raw.update(
            'auto_daily_status',
            <String, Object?>{'deleted_at': testTimestamp},
            where: 'id = ?',
            whereArgs: <Object?>[status],
          );

      await expectDbError(softDeleteStatus(), 'HAS_PAYMENTS');

      await db.raw.update(
        'auto_deposits',
        <String, Object?>{'deleted_at': testTimestamp},
        where: 'id = ?',
        whereArgs: <Object?>[deposit],
      );
      expect(await softDeleteStatus(), 1);

      // The unique rule only covers active rows, so the day can be entered again.
      final again = await insertAutoStatus(db, auto, driver);
      expect(again, isNot(status));
    });
  });

  group('expenses', () {
    Future<int> householdCategory() async {
      final rows = await db.raw.query(
        'expense_categories',
        columns: <String>['id'],
        where: "scope = 'household'",
        limit: 1,
      );
      return rows.first['id']! as int;
    }

    test('a valid household expense: 150.50 Taka', () async {
      final category = await householdCategory();
      final id = await db.raw.insert('household_expenses', <String, Object?>{
        ...txnFields(),
        'category_id': category,
        'shop_or_person': 'Bazar',
        'amount_paisa': 15050,
      });
      expect(id, greaterThan(0));
    });

    test('zero and negative amounts are refused', () async {
      final category = await householdCategory();
      for (final amount in <int>[0, -5]) {
        await expectDbError(
          db.raw.insert('household_expenses', <String, Object?>{
            ...txnFields(),
            'category_id': category,
            'amount_paisa': amount,
          }),
          'CHECK',
        );
      }
    });

    test('a general expense needs a description and a valid flag', () async {
      final category = await householdCategory();
      await expectDbError(
        db.raw.insert('general_expenses', <String, Object?>{
          ...txnFields(),
          'category_id': category,
          'amount_paisa': 100,
        }),
        'NOT NULL',
      );
      await expectDbError(
        db.raw.insert('general_expenses', <String, Object?>{
          ...txnFields(),
          'category_id': category,
          'description': 'Ice',
          'amount_paisa': 100,
          'chicken_related': 2,
        }),
        'CHECK',
      );
    });
  });
}
