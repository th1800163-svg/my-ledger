import 'package:amar_hisab/core/errors/app_exception.dart';
import 'package:amar_hisab/core/money/money.dart';
import 'package:amar_hisab/core/money/weight.dart';
import 'package:amar_hisab/core/validation/validators.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('money', () {
    test('valid amounts', () {
      expect(Validators.money('7000').valueOrNull, Money.fromTaka(7000));
      expect(Validators.money('12.5').valueOrNull, const Money(1250));
      expect(Validators.money('১২৫').valueOrNull, Money.fromTaka(125));
      expect(Validators.money('1,250').valueOrNull, Money.fromTaka(1250));
    });

    test('empty is an error when required', () {
      expect(Validators.money('').errorOrNull, 'Amount is required');
      expect(Validators.money(null).errorOrNull, 'Amount is required');
    });

    test('empty means zero when not required', () {
      expect(Validators.money('', required: false).valueOrNull, Money.zero);
    });

    test('zero is rejected unless allowed', () {
      expect(Validators.money('0').errorOrNull, 'Amount must be greater than zero');
      expect(Validators.money('0', allowZero: true).valueOrNull, Money.zero);
    });

    test('negative, text and too many decimals', () {
      expect(Validators.money('-5').errorOrNull, 'Amount cannot be negative');
      expect(Validators.money('abc').errorOrNull, 'Amount must be a number');
      expect(Validators.money('12.345').errorOrNull, 'Amount can have at most 2 decimal places');
    });

    test('custom label appears in the message', () {
      expect(
        Validators.money('', label: 'Transport cost').errorOrNull,
        'Transport cost is required',
      );
    });

    test('upper limit is 1 crore Taka', () {
      expect(Validators.money('10000000').isValid, isTrue);
      expect(
        Validators.money('10000001').errorOrNull,
        'Amount cannot be more than ৳1,00,00,000',
      );
    });
  });

  group('rate per kg', () {
    test('valid and invalid', () {
      expect(Validators.ratePerKg('220').valueOrNull, Money.fromTaka(220));
      expect(Validators.ratePerKg('0').errorOrNull, 'Rate per kg must be greater than zero');
      expect(
        Validators.ratePerKg('10000.01').errorOrNull,
        'Rate per kg cannot be more than ৳10,000',
      );
      expect(Validators.ratePerKg('10000').isValid, isTrue);
    });
  });

  group('weight', () {
    test('valid weights', () {
      expect(Validators.weightKg('2.5').valueOrNull, const Weight(2500));
      expect(Validators.weightKg('20').valueOrNull, Weight.fromKg(20));
      expect(Validators.weightKg('0.001').valueOrNull, const Weight(1));
    });

    test('invalid weights', () {
      expect(Validators.weightKg('').errorOrNull, 'Weight is required');
      expect(Validators.weightKg('0').errorOrNull, 'Weight must be greater than zero');
      expect(Validators.weightKg('-1').errorOrNull, 'Weight cannot be negative');
      expect(
        Validators.weightKg('2.5555').errorOrNull,
        'Weight can have at most 3 decimal places',
      );
      expect(
        Validators.weightKg('50001').errorOrNull,
        'Weight cannot be more than 50000 kg',
      );
      expect(Validators.weightKg('50000').isValid, isTrue);
    });

    test('optional weight: blank is fine and gives null', () {
      final blank = Validators.optionalWeightKg('');
      expect(blank.isValid, isTrue);
      expect(blank.valueOrNull, isNull);
      expect(Validators.optionalWeightKg('   ').isValid, isTrue);
      expect(Validators.optionalWeightKg('2').valueOrNull, Weight.fromKg(2));
      expect(Validators.optionalWeightKg('0').errorOrNull, 'Weight must be greater than zero');
    });
  });

  group('pieces', () {
    test('valid', () {
      expect(Validators.pieces('10').valueOrNull, 10);
      expect(Validators.pieces('১০').valueOrNull, 10);
      expect(Validators.pieces('0', allowZero: true).valueOrNull, 0);
    });

    test('invalid', () {
      expect(Validators.pieces('').errorOrNull, 'Pieces is required');
      expect(Validators.pieces('0').errorOrNull, 'Pieces must be greater than zero');
      expect(Validators.pieces('-1').errorOrNull, 'Pieces cannot be negative');
      expect(Validators.pieces('2.5').errorOrNull, 'Pieces must be a whole number');
      expect(Validators.pieces('abc').errorOrNull, 'Pieces must be a whole number');
      expect(Validators.pieces('100001').errorOrNull, 'Pieces cannot be more than 100000');
      expect(Validators.pieces('100000').isValid, isTrue);
    });

    test('not required: blank means zero', () {
      expect(Validators.pieces('', required: false).valueOrNull, 0);
    });
  });

  group('percent', () {
    test('valid and invalid', () {
      expect(Validators.percent('50').valueOrNull, 50);
      expect(Validators.percent('0').valueOrNull, 0);
      expect(Validators.percent('100').valueOrNull, 100);
      expect(Validators.percent('101').errorOrNull, 'Percentage must be between 0 and 100');
      expect(Validators.percent('-1').errorOrNull, 'Percentage cannot be negative');
      expect(Validators.percent('').errorOrNull, 'Percentage is required');
      expect(Validators.percent('12.5').errorOrNull, 'Percentage must be a whole number');
    });
  });

  group('name and text', () {
    test('name is trimmed and spaces collapsed', () {
      expect(Validators.name('  Rahim   Uddin ').valueOrNull, 'Rahim Uddin');
    });

    test('name required and length limited', () {
      expect(Validators.name('').errorOrNull, 'Name is required');
      expect(Validators.name('   ').errorOrNull, 'Name is required');
      expect(Validators.name(null).errorOrNull, 'Name is required');
      expect(Validators.name('a' * 80).isValid, isTrue);
      expect(Validators.name('a' * 81).errorOrNull, 'Name can have at most 80 characters');
      expect(Validators.name('', label: 'Hotel name').errorOrNull, 'Hotel name is required');
    });

    test('optional text', () {
      expect(Validators.optionalText('').valueOrNull, isNull);
      expect(Validators.optionalText('  hi ').valueOrNull, 'hi');
      expect(Validators.optionalText('a' * 500).isValid, isTrue);
      expect(
        Validators.optionalText('a' * 501).errorOrNull,
        'Notes can have at most 500 characters',
      );
    });
  });

  group('phone', () {
    test('blank is allowed', () {
      expect(Validators.phone('').isValid, isTrue);
      expect(Validators.phone('').valueOrNull, isNull);
      expect(Validators.phone(null).isValid, isTrue);
    });

    test('valid number is returned in canonical form', () {
      expect(Validators.phone('+8801712345678').valueOrNull, '01712345678');
    });

    test('invalid number', () {
      expect(
        Validators.phone('12345').errorOrNull,
        'Enter a valid Bangladeshi phone number, for example 01712345678',
      );
    });
  });

  group('notInFuture', () {
    final now = DateTime(2026, 10, 7, 15, 45);

    test('now, the past and a few seconds ahead are fine', () {
      expect(Validators.notInFuture(now, now).isValid, isTrue);
      expect(Validators.notInFuture(DateTime(2026, 1, 1), now).isValid, isTrue);
      expect(
        Validators.notInFuture(now.add(const Duration(seconds: 30)), now).isValid,
        isTrue,
      );
    });

    test('two minutes ahead is rejected', () {
      expect(
        Validators.notInFuture(now.add(const Duration(minutes: 2)), now).errorOrNull,
        'The date and time cannot be in the future',
      );
      expect(Validators.notInFuture(DateTime(2026, 10, 8), now).isValid, isFalse);
    });
  });

  group('receiveAmount (no advance payments)', () {
    final due = Money.fromTaka(1000);

    test('partial and exact amounts', () {
      expect(Validators.receiveAmount(Money.fromTaka(400), due).isValid, isTrue);
      expect(Validators.receiveAmount(due, due).isValid, isTrue);
    });

    test('more than due is rejected with the maximum in the message', () {
      expect(
        Validators.receiveAmount(const Money(100001), due).errorOrNull,
        'You can receive at most ৳1,000 (the amount still due)',
      );
    });

    test('zero is rejected', () {
      expect(
        Validators.receiveAmount(Money.zero, due).errorOrNull,
        'Amount must be greater than zero',
      );
    });

    test('nothing due', () {
      expect(
        Validators.receiveAmount(Money.fromTaka(1), Money.zero).errorOrNull,
        'Nothing is due',
      );
    });
  });

  group('paidAtSale', () {
    final total = Money.fromTaka(7000);

    test('from zero up to the total', () {
      expect(Validators.paidAtSale(Money.zero, total).isValid, isTrue);
      expect(Validators.paidAtSale(Money.fromTaka(3000), total).isValid, isTrue);
      expect(Validators.paidAtSale(total, total).isValid, isTrue);
    });

    test('negative and above total', () {
      expect(
        Validators.paidAtSale(const Money(-1), total).errorOrNull,
        'Paid amount cannot be negative',
      );
      expect(
        Validators.paidAtSale(const Money(700001), total).errorOrNull,
        'The paid amount cannot be more than the total (৳7,000)',
      );
    });
  });

  group('requireValue', () {
    test('returns the value when valid', () {
      expect(Validators.money('10').requireValue, Money.fromTaka(10));
    });

    test('throws ValidationException with the message when invalid', () {
      expect(
        () => Validators.money('-1').requireValue,
        throwsA(
          isA<ValidationException>().having((e) => e.message, 'message', 'Amount cannot be negative'),
        ),
      );
    });
  });

  group('form field adapters', () {
    test('return null when valid and a message when not', () {
      expect(Validators.moneyField()('12'), isNull);
      expect(Validators.moneyField()(''), 'Amount is required');
      expect(Validators.weightField()('2.5'), isNull);
      expect(Validators.optionalWeightField()(''), isNull);
      expect(Validators.piecesField()('0'), 'Pieces must be greater than zero');
      expect(Validators.nameField(label: 'Dealer name')(''), 'Dealer name is required');
      expect(Validators.phoneField()('x'), isNotNull);
      expect(Validators.rateField()('220'), isNull);
      expect(Validators.percentField()('50'), isNull);
      expect(Validators.notesField()(''), isNull);
    });
  });
}
