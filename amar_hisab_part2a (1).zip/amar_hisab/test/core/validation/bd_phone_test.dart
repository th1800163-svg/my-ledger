import 'package:amar_hisab/core/validation/bd_phone.dart';
import 'package:flutter_test/flutter_test.dart';

void main() {
  group('BdPhone.normalize accepts and canonicalises', () {
    test('plain mobile number', () {
      expect(BdPhone.normalize('01712345678'), '01712345678');
    });

    test('spaces, dashes and brackets are removed', () {
      expect(BdPhone.normalize('01712 345 678'), '01712345678');
      expect(BdPhone.normalize('017-1234-5678'), '01712345678');
      expect(BdPhone.normalize('(017) 1234 5678'), '01712345678');
    });

    test('country code forms', () {
      expect(BdPhone.normalize('+8801712345678'), '01712345678');
      expect(BdPhone.normalize('8801712345678'), '01712345678');
      expect(BdPhone.normalize('+880 1712-345678'), '01712345678');
    });

    test('Bengali digits', () {
      expect(BdPhone.normalize('০১৭১২৩৪৫৬৭৮'), '01712345678');
    });

    test('every mobile operator digit from 3 to 9', () {
      for (final digit in <String>['3', '4', '5', '6', '7', '8', '9']) {
        expect(BdPhone.isValid('01${digit}1234567'.padRight(11, '0')), isTrue, reason: digit);
      }
    });

    test('landline numbers', () {
      expect(BdPhone.normalize('02-9876543'), '029876543');
      expect(BdPhone.normalize('031 2512345'), '0312512345');
    });
  });

  group('BdPhone.normalize rejects', () {
    test('wrong lengths', () {
      expect(BdPhone.normalize('1712345678'), isNull);
      expect(BdPhone.normalize('0171234567'), isNull);
      expect(BdPhone.normalize('017123456789'), isNull);
    });

    test('invalid mobile operator digit', () {
      expect(BdPhone.normalize('01212345678'), isNull);
      expect(BdPhone.normalize('01012345678'), isNull);
    });

    test('letters, empty and foreign numbers', () {
      expect(BdPhone.normalize('abc'), isNull);
      expect(BdPhone.normalize(''), isNull);
      expect(BdPhone.normalize('+44 7911 123456'), isNull);
      expect(BdPhone.normalize('017123abc78'), isNull);
    });
  });

  test('dialerUri builds a tel: link', () {
    expect(BdPhone.dialerUri('01712345678').toString(), 'tel:01712345678');
  });
}
